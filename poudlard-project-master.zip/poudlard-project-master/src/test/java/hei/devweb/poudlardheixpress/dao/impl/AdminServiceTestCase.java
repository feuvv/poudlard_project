package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.Admin;
import hei.devweb.poudlardheixpress.services.AdminService;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

public class AdminServiceTestCase {
    private AdminService adminService = new AdminService();

    @Before
    public void initDb() throws Exception {
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement statement = connection.createStatement()) {
            statement.executeUpdate("DELETE FROM communaute");
            statement.executeUpdate("INSERT INTO `communaute`(`id_com`, `prenom_com`, `nom_com`, `pseudo_com`, `identifiant_com`, `mdp_com`) VALUES (1, 'TestPrenom', 'TestNom', 'TestPseudo', 'TestIdentifiant', 'TestMDP')");
            statement.executeUpdate("INSERT INTO `communaute`(`id_com`, `prenom_com`, `nom_com`, `pseudo_com`, `identifiant_com`, `mdp_com`) VALUES (2, 'TestPrenom2', 'TestNom2', 'TestPseudo2', 'TestIdentifiant2', 'TestMDP2')");
        }
    }

    @Test
    public void shouldListAdmin() {
        //WHEN
        List<Admin> admins = adminService.listAllUsers();

        //THEN
        assertThat(admins).hasSize(2);
        assertThat(admins).extracting("id_com", "prenom_com", "nom_com", "pseudo_com", "identifiant_com", "mdp_com").containsOnly(
                tuple(1, "TestPrenom", "TestNom", "TestPseudo", "TestIdentifiant", "TestMDP"),
                tuple(2, "TestPrenom2", "TestNom2", "TestPseudo2", "TestIdentifiant2", "TestMDP2")
        );
    }
}
