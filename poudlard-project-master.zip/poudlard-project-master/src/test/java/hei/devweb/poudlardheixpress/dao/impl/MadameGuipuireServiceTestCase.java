package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.MadameGuipuire;
import hei.devweb.poudlardheixpress.services.MadameGuipuireService;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

public class MadameGuipuireServiceTestCase {
    private MadameGuipuireService madameGuipuireService = new MadameGuipuireService();

    @Before
    public void initDb() throws Exception {
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement statement = connection.createStatement()) {
            statement.executeUpdate("DELETE FROM madameguipuire");
            statement.executeUpdate("INSERT INTO `madameguipuire`(`id_gu`, `titre_gu`, `image_gu`, `description_gu`, `prix_gu`) VALUES (1, 'TestTitre', 'TestImage', 'TestDescription', 5)");
            statement.executeUpdate("INSERT INTO `madameguipuire`(`id_gu`, `titre_gu`, `image_gu`, `description_gu`, `prix_gu`) VALUES (2, 'TestTitre2', 'TestImage2', 'TestDescription2', 5)");
        }
    }

    @Test
    public void shouldListMadameGuipuire() {
        //WHEN
        List<MadameGuipuire> madameGuipuires = madameGuipuireService.listAllMadameGuipuire();

        //THEN
        assertThat(madameGuipuires).hasSize(2);
        assertThat(madameGuipuires).extracting("id_gu", "titre_gu", "image_gu", "description_gu", "prix_gu").containsOnly(
                tuple(1, "TestTitre", "TestImage", "TestDescription", 5),
                tuple(2, "TestTitre2", "TestImage2", "TestDescription2", 5)
        );
    }
}
