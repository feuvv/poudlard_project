package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.Quidditch;
import hei.devweb.poudlardheixpress.services.QuidditchService;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

public class QuidditchServiceTestCase {
    private QuidditchService quidditchService = new QuidditchService();

    @Before
    public void intiDb() throws Exception {
        try(Connection connection = DataSourceProvider.getDataSource().getConnection();
            Statement statement = connection.createStatement()) {
            statement.executeUpdate("DELETE FROM quidditch");
            statement.executeUpdate("INSERT INTO `quidditch`(`id_qd`,`titre_qd`,`image_qd`,`description_qd`,`prix_qd`) VALUES (1, 'TestTitre', 'TestImage', 'TestDescription', 2)");
            statement.executeUpdate("INSERT INTO `quidditch`(`id_qd`,`titre_qd`,`image_qd`,`description_qd`,`prix_qd`) VALUES (2, 'TestTitre2', 'TestImage2', 'TestDescription2', 2)");
        }
    }

    @Test
    public void shouldListQuidditch() {
        //WHEN
        List<Quidditch> quidditchs = quidditchService.listAllQuidditch();

        //THEN
        assertThat(quidditchs).hasSize(2);
        assertThat(quidditchs).extracting("id_qd", "titre_qd", "image_qd", "description_qd", "prix_qd").containsOnly(
                tuple(1, "TestTitre", "TestImage", "TestDescription", 2),
                tuple(2, "TestTitre2", "TestImage2", "TestDescription2", 2)
        );
    }
}
