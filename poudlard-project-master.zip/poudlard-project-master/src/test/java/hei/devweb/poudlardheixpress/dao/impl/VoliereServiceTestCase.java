package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.Voliere;
import hei.devweb.poudlardheixpress.services.VoliereService;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

public class VoliereServiceTestCase {
    private VoliereService voliereService = new VoliereService();

    @Before
    public void initDb() throws Exception {
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement statement = connection.createStatement()) {
            statement.executeUpdate("DELETE FROM voliere");
            statement.executeUpdate("INSERT INTO `voliere`(`id_vol`,`com_vol`,`pseudo_vol`) VALUES (1, 'TestCom', 1)");
            statement.executeUpdate("INSERT INTO `voliere`(`id_vol`,`com_vol`,`pseudo_vol`) VALUES (2, 'TestCom2', 2)");
        }
    }

    @Test
    public void shouldListVoliere() {
        //WHEN
        List<Voliere> volieres = voliereService.listAllVoliere();

        //THEN
        assertThat(volieres).hasSize(2);
        assertThat(volieres).extracting("id_vol", "com_vol", "pseudo_vol").containsOnly(
                tuple(1, "TestCom", 1),
                tuple(2, "TestCom2", 2)
        );
    }
}
