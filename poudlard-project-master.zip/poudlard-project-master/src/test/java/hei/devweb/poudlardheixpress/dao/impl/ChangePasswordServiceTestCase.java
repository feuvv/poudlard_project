package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.Connexion;
import hei.devweb.poudlardheixpress.services.ChangePwdService;
import hei.devweb.poudlardheixpress.services.ConnexionService;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class ChangePasswordServiceTestCase {

    private ConnexionService connexionService = new ConnexionService();
    private ChangePwdService changePwdService = new ChangePwdService();

    @Before
    public void initDb() throws Exception {
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement statement = connection.createStatement()) {
            statement.executeUpdate("DELETE FROM communaute");
            statement.executeUpdate("INSERT INTO `communaute`(`id_com`, `prenom_com`, `nom_com`, `pseudo_com`, `identifiant_com`, `mdp_com`, `role_com` ) VALUES (1, 'null', 'null', 'null', 'TestIdentifiant', 'TestMDP','null')");
        }
    }

    @Test
    public void shouldListConnexion() {
        //WHEN
        List<Connexion> connexion = (List<Connexion>) connexionService.listAllConnexion();

        //THEN
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement stmt = connection.createStatement()) {
            try (ResultSet rs = stmt.executeQuery("SELECT * FROM communaute WHERE identifiant_com='TestIdentifiant' AND mdp_com='TestMDP' AND id_com='1'")) {
                assertThat(rs.next()).isTrue();
                assertThat(rs.getInt("id_com")).isEqualTo(1);
                assertThat(rs.getString("prenom_com")).isEqualTo("null");
                assertThat(rs.getString("nom_com")).isEqualTo("null");
                assertThat(rs.getString("pseudo_com")).isEqualTo("null");
                assertThat(rs.getString("identifiant_com")).isEqualTo("TestIdentifiant");
                assertThat(rs.getString("mdp_com")).isEqualTo("TestMDP");
                assertThat(rs.getString("role_com")).isEqualTo("null");

                assertThat(rs.next()).isFalse();

                changePwdService.setChangePwdDao("TestMDP","TestIdentifiant");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
