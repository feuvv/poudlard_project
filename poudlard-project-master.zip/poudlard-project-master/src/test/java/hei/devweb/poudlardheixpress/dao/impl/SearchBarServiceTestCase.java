package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.FleuryBott;
import hei.devweb.poudlardheixpress.entities.MadameGuipuire;
import hei.devweb.poudlardheixpress.entities.Ollivander;
import hei.devweb.poudlardheixpress.entities.Quidditch;
import hei.devweb.poudlardheixpress.services.SearchBarService;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

public class SearchBarServiceTestCase {
    private SearchBarService searchBarService = new SearchBarService();

    @Before
    public void initDb() throws Exception {
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement statement = connection.createStatement()) {
            statement.executeUpdate("DELETE FROM ollivander");
            statement.executeUpdate("DELETE FROM quidditch");
            statement.executeUpdate("DELETE FROM madameguipuire");
            statement.executeUpdate("DELETE FROM fleurybott");
            statement.executeUpdate("INSERT INTO `ollivander`(`id_ol`, `titre_ol`, `image_ol`, `prix_ol`, `description_ol`, `type_ol`) VALUES (1, 'TestTitre', 'TestImage', 2 , 'TestDescription', 'TestType')");
            statement.executeUpdate("INSERT INTO `quidditch`(`id_qd`, `titre_qd`, `image_qd`, `description_qd`, `prix_qd`) VALUES (1, 'TestTitre', 'TestImage', 'TestDescription', 2)");
            statement.executeUpdate("INSERT INTO `madameguipuire`(`id_gu`, `titre_gu`, `image_gu`, `description_gu`, `prix_gu`) VALUES (1, 'TestTitre', 'TestImage', 'TestDescription', 2)");
            statement.executeUpdate("INSERT INTO `fleurybott`(`id_livre`, `titre_livre`, `type_livre`, `image_livre`, `prix_livre`, `auteur_livre`, `description_livre`) VALUES (1, 'TestTitre', 'TestType', 'TestImage', 2 , 'TestAuteur', 'TestDescription')");
        }
    }

    @Test
    public void shouldListOllivander() throws SQLException {
        //GIVEN
        String search = "TestTitre";
        List<Ollivander> ollivanders = searchBarService.listSearchOllivander(search);

        //THEN
        assertThat(ollivanders).hasSize(1);
        assertThat(ollivanders).extracting("id_ol", "titre_ol", "image_ol", "prix_ol", "description_ol", "type_ol").containsOnly(
                tuple(1, "TestTitre", "TestImage", 2.0, "TestDescription", "TestType")
        );

    }

    @Test
    public void shouldListQuidditch() throws SQLException {
        //GIVEN
        String search = "TestTitre";
        List<Quidditch> quidditches = searchBarService.listSearchQuidditch(search);

        //THEN
        assertThat(quidditches).hasSize(1);
        assertThat(quidditches).extracting("id_qd", "titre_qd", "image_qd", "description_qd", "prix_qd").containsOnly(
                tuple(1, "TestTitre", "TestImage", "TestDescription", 2)
        );
    }

    @Test
    public void shouldListMadameGuipuire() throws SQLException {
        //GIVEN
        String search = "TestTitre";
        List<MadameGuipuire> madameGuipuires = searchBarService.listSearchMadameGuipire(search);

        //THEN
        assertThat(madameGuipuires).hasSize(1);
        assertThat(madameGuipuires).extracting("id_gu","titre_gu", "image_gu", "description_gu", "prix_gu").containsOnly(
                  tuple(1, "TestTitre", "TestImage", "TestDescription", 2)
        );
    }

    @Test
    public void shouldListFleuryBott() throws SQLException {
        //GIVEN
        String search ="TestTitre";
        List<FleuryBott> fleuryBotts = searchBarService.listSearchFleuryBott(search);

        //THEN
        assertThat(fleuryBotts).hasSize(1);
        assertThat(fleuryBotts).extracting("id_livre", "titre_livre", "type_livre", "image_livre", "prix_livre", "auteur_livre", "description_livre").containsOnly(
                tuple(1, "TestTitre", "TestType", "TestImage", 2.0, "TestAuteur", "TestDescription")
        );
    }
}
