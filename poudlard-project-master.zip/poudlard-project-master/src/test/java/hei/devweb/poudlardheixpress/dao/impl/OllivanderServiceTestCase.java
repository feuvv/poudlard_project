package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.Ollivander;
import hei.devweb.poudlardheixpress.services.OllivanderService;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

public class OllivanderServiceTestCase {
    private OllivanderService ollivanderService = new OllivanderService();

    @Before
    public void initDb() throws Exception {
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement statement = connection.createStatement()) {
            statement.executeUpdate("DELETE FROM ollivander");
            statement.executeUpdate("INSERT INTO `ollivander`(`id_ol`,`titre_ol`,`image_ol`,`prix_ol`,`description_ol`,`type_ol`) VALUES (1, 'TestTitre', 'TestImage', 3, 'TestDescription', 'TestType')");
            statement.executeUpdate("INSERT INTO `ollivander`(`id_ol`,`titre_ol`,`image_ol`,`prix_ol`,`description_ol`,`type_ol`) VALUES (2, 'TestTitre2', 'TestImage2', 4, 'TestDescription2', 'TestType2')");
        }
    }

    @Test
    public void shouldListOllivander() {
        //WHEN
        List<Ollivander> ollivanders = ollivanderService.listAllOllivander();

        //THEN
        assertThat(ollivanders).hasSize(2);
        assertThat(ollivanders).extracting("id_ol", "titre_ol", "image_ol", "prix_ol", "description_ol", "type_ol").containsOnly(
                tuple(1, "TestTitre", "TestImage", 3.0, "TestDescription", "TestType"),
                tuple(2, "TestTitre2", "TestImage2", 4.0, "TestDescription2", "TestType2")
        );
    }


}
