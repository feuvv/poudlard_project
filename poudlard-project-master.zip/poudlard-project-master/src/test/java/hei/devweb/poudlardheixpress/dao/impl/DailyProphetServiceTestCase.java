package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.DailyProphet;
import hei.devweb.poudlardheixpress.services.DailyProphetService;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

public class DailyProphetServiceTestCase {
    private DailyProphetService dailyProphetService = new DailyProphetService();

    @Before
    public void initDb() throws Exception {
       try (Connection connection = DataSourceProvider.getDataSource().getConnection();
            Statement statement = connection.createStatement()
       ) {
           statement.executeUpdate("DELETE FROM dailyprophet");
           statement.executeUpdate("INSERT INTO `dailyprophet`(`id_news`, `titre_news`, `article_news`, `rubrique_news`, `auteur_news`, `datepub_news`) VALUES (1, 'TestTitre', 'TestArticle', 'TestRubrique', 'TestAuteur', 'TestDatePub')");
           statement.executeUpdate("INSERT INTO `dailyprophet`(`id_news`, `titre_news`, `article_news`, `rubrique_news`, `auteur_news`, `datepub_news`) VALUES (2, 'TestTitre2', 'TestArticle2', 'TestRubrique2', 'TestAuteur2', 'TestDatePub2')");
       }
    }

    @Test
    public void shouldListDailyProphet() {
        //WHEN
        List<DailyProphet> dailyProphets = dailyProphetService.listAllDailyProphet();

        //THEN
        assertThat(dailyProphets).hasSize(2);
        assertThat(dailyProphets).extracting("id_news", "titre_news", "article_news", "rubrique_news", "auteur_news", "datepub_news").containsOnly(
                tuple(1, "TestTitre", "TestArticle", "TestRubrique", "TestAuteur", "TestDatePub"),
                tuple(2, "TestTitre2", "TestArticle2", "TestRubrique2", "TestAuteur2", "TestDatePub2")
        );
    }
}
