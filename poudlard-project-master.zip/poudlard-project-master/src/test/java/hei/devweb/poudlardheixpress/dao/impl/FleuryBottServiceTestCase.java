package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.FleuryBott;
import hei.devweb.poudlardheixpress.services.FleuryBottService;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

public class FleuryBottServiceTestCase {
    private FleuryBottService fleuryBottService = new FleuryBottService();

    @Before
    public void initDb() throws Exception  {
        try(Connection connection = DataSourceProvider.getDataSource().getConnection();
            Statement statement = connection.createStatement()) {
            statement.executeUpdate("DELETE FROM fleurybott");
            statement.executeUpdate("INSERT INTO `fleurybott`(`id_livre`, `titre_livre`, `type_livre`, `image_livre`, `prix_livre`, `auteur_livre`, `description_livre`) VALUES (1, 'TestTitre', 'TestType', 'ImageTest', 3, 'AuteurTest', 'DescriptionTest')");
            statement.executeUpdate("INSERT INTO `fleurybott`(`id_livre`, `titre_livre`, `type_livre`, `image_livre`, `prix_livre`, `auteur_livre`, `description_livre`) VALUES (2, 'TestTitre2', 'TestType2', 'ImageTest2', 3, 'AuteurTest2', 'DescriptionTest2')");
        }
    }

    @Test
    public void shouldListFleuryBott() {
        //WHEN
        List<FleuryBott> fleuryBotts = fleuryBottService.listAllFleuryBott();

        //THEN
        assertThat(fleuryBotts).hasSize(2);
        assertThat(fleuryBotts).extracting("id_livre", "titre_livre", "type_livre", "image_livre", "prix_livre", "auteur_livre", "description_livre").containsOnly(
                tuple(1, "TestTitre", "TestType", "ImageTest", 3.0, "AuteurTest", "DescriptionTest"),
                tuple(2, "TestTitre2", "TestType2", "ImageTest2", 3.0, "AuteurTest2", "DescriptionTest2")
        );
    }
}
