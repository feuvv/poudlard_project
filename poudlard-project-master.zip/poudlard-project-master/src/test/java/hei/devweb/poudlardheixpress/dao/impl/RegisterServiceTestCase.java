package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.Register;
import hei.devweb.poudlardheixpress.services.RegisterServices;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import static org.assertj.core.api.Assertions.assertThat;

public class RegisterServiceTestCase {
    private RegisterServices registerServices = new RegisterServices();

    @Test
    public void shouldAddUser() throws Exception {
        //GIVEN
        Register userToCreate = new Register(null,
                "NomUser",
                "PrenomUser",
                "user@gmail.com",
                "mdp",
                "user",
                "Utilisateur");

        //WHEN
        Register userCreated = registerServices.addUser(userToCreate);

        //THEN
        assertThat(userCreated).isNotNull();
        assertThat(userCreated.getId()).isNotNull();
        assertThat(userCreated.getNom()).isEqualTo("NomUser");
        assertThat(userCreated.getPrenom()).isEqualTo("PrenomUser");
        assertThat(userCreated.getMail()).isEqualTo("user@gmail.com");
        assertThat(userCreated.getMdp()).isEqualTo("mdp");
        assertThat(userCreated.getPseudo()).isEqualTo("user");
        assertThat(userCreated.getRole()).isEqualTo("Utilisateur");

        try(Connection connection = DataSourceProvider.getDataSource().getConnection();
            Statement statement = connection.createStatement()) {
            try (ResultSet resultSet = statement.executeQuery("SELECT * FROM communaute WHERE pseudo_com = 'user'")) {
                assertThat(resultSet.next()).isTrue();
                assertThat(resultSet.getInt("id_com")).isEqualTo(userCreated.getId());
                assertThat(resultSet.getString("nom_com")).isEqualTo("NomUser");
                assertThat(resultSet.getString("prenom_com")).isEqualTo("PrenomUser");
                assertThat(resultSet.getString("identifiant_com")).isEqualTo("user@gmail.com");
                assertThat(resultSet.getString("mdp_com")).isEqualTo("mdp");
                assertThat(resultSet.getString("pseudo_com")).isEqualTo("user");
                assertThat(resultSet.getString("role_com")).isEqualTo("Utilisateur");

                assertThat(resultSet.next()).isFalse();
            }
        }



    }
}
