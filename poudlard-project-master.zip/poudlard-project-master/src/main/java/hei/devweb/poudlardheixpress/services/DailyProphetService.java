package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.impl.DailyProphetDaoImpl;
import hei.devweb.poudlardheixpress.entities.DailyProphet;

import java.util.List;

public class DailyProphetService {
    private DailyProphetDaoImpl dailyProphetDaoImpl = new DailyProphetDaoImpl();

    private static class DailyProphetServiceHolder {
        private static DailyProphetService instance = new DailyProphetService();
    }

    public static DailyProphetService getInstance() {
        return DailyProphetService.DailyProphetServiceHolder.instance;
    }

    public DailyProphetService() {

    }

    public List<DailyProphet> listAllDailyProphet() {

        return dailyProphetDaoImpl.listAllDailyProphet();
    }
}
