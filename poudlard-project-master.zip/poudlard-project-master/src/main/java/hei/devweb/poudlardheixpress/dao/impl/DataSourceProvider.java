package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.tools.PropertiesManager;
import org.mariadb.jdbc.MariaDbDataSource;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.SQLException;

public class DataSourceProvider {

    private static MariaDbDataSource dataSource;

    public static DataSource getDataSource() throws SQLException, IOException {
        PropertiesManager dbProperties = new PropertiesManager("dbconnexion");

        if (dataSource == null) {
            dataSource = new MariaDbDataSource();
            dataSource.setServerName(dbProperties.readProperty("db.host"));
            dataSource.setPort(Integer.parseInt(dbProperties.readProperty("db.port")));
            dataSource.setDatabaseName("poudlard-project");
            dataSource.setUser(dbProperties.readProperty("db.login"));
            dataSource.setPassword(dbProperties.readProperty("db.password"));
        }
        return dataSource;
    }
}