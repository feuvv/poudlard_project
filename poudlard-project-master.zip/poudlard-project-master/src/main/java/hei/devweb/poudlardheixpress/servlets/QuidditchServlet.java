package hei.devweb.poudlardheixpress.servlets;

import hei.devweb.poudlardheixpress.entities.Quidditch;
import hei.devweb.poudlardheixpress.services.QuidditchService;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/quidditch")
public class QuidditchServlet extends AbstractServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContextTemplateResolver resolver = generateTemplateResolver(request, response);
        resolver.setPrefix("/WEB-INF/templates/marketplace/");

        TemplateEngine engine = generateTemplateEngine(request, response);
        engine.setTemplateResolver(resolver);
        WebContext context = new WebContext(request, response, request.getServletContext());
        List<Quidditch> listQuidditch = QuidditchService.getInstance().listAllQuidditch();
        context.setVariable("mQuidditchs", listQuidditch);
        engine.process("quidditch", context, response.getWriter());
    }
}
