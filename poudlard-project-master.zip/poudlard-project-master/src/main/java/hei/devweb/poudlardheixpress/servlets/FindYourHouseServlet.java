package hei.devweb.poudlardheixpress.servlets;

import hei.devweb.poudlardheixpress.services.SortingService;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/findyourhouse")
public class FindYourHouseServlet extends AbstractServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        ServletContextTemplateResolver resolver = generateTemplateResolver(request, response);
        resolver.setPrefix("/WEB-INF/templates/poudlard/houses/");

        TemplateEngine engine = generateTemplateEngine(request, response);
        engine.setTemplateResolver(resolver);

        WebContext context = new WebContext(request, response, request.getServletContext());

        try {
            String maison = SortingService.getInstance().getHouse(request);
            context.setVariable("maison", maison);
        } catch (NullPointerException e) {
            System.out.println("Null");
            //c'est pour ça qu"il faut bien remplir le questionnaire
            context.setVariable("maison", "Poufsouffle");
        }


        engine.process("house", context, response.getWriter());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) {

    }
}
