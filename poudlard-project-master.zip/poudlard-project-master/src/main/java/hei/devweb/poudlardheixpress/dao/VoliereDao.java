package hei.devweb.poudlardheixpress.dao;

import hei.devweb.poudlardheixpress.entities.Voliere;

import java.util.List;

public interface VoliereDao {
    public List<Voliere> listAllVoliere();
}
