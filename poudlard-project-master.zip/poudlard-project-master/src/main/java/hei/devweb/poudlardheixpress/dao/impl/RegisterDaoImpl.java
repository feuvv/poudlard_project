package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.Register;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RegisterDaoImpl {

    public Register addUser(Register user) {

        String sqlQuery1 = "INSERT INTO communaute(id_com, prenom_com, nom_com, pseudo_com, identifiant_com , mdp_com, role_com) VALUES(null ,?, ?, ?, ?, ?, ?);";
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sqlQuery1, Statement.RETURN_GENERATED_KEYS)) {
                statement.setString(1, user.getPrenom());
                statement.setString(2, user.getNom());
                statement.setString(3, user.getPseudo());
                statement.setString(4, user.getMail());
                statement.setString(5, user.getMdp());
                statement.setString(6, user.getRole());

                statement.executeUpdate();

                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        user.setId(generatedKeys.getInt(1));
                        return user;
                    }
                }
            }



        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    //Récupérer la liste des pseudos de la BDD
    public List<String> verifyPseudo() {
        String sqlQuery = "SELECT pseudo_com FROM communaute";
        List<String> pseudoBDD=new ArrayList<>() ;
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try(Statement statement = connection.createStatement()) {
                try(ResultSet resultSet = statement.executeQuery(sqlQuery)){
                    while(resultSet.next())
                    pseudoBDD.add(resultSet.getString("pseudo_com"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return pseudoBDD;
    }

}