package hei.devweb.poudlardheixpress.entities;

public class Quidditch {
    private Integer id_qd;
    private String titre_qd;
    private String image_qd;
    private String description_qd;
    private int prix_qd;

    public Quidditch(Integer id, String titre, String image, String description, int prix) {
        super();
        this.id_qd = id;
        this.titre_qd = titre;
        this.image_qd = image;
        this.description_qd = description;
        this.prix_qd = prix;
    }

    public Integer getId_qd() {
        return id_qd;
    }

    public void setId_qd(Integer id_qd) {
        this.id_qd = id_qd;
    }

    public String getTitre_qd() {
        return titre_qd;
    }

    public void setTitre_qd(String titre_qd) {
        this.titre_qd = titre_qd;
    }

    public String getImage_qd() {
        return image_qd;
    }

    public void setImage_qd(String image_qd) {
        this.image_qd = image_qd;
    }

    public String getDescription_qd() {
        return description_qd;
    }

    public void setDescription_qd(String description_qd) {
        this.description_qd = description_qd;
    }

    public int getPrix_qd() {
        return prix_qd;
    }

    public void setPrix_qd(int prix_qd) {
        this.prix_qd = prix_qd;
    }
}
