package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.impl.OllivanderDaoImpl;
import hei.devweb.poudlardheixpress.entities.Ollivander;

import java.util.List;

public class OllivanderService {
    private OllivanderDaoImpl ollivanderDaoImpl = new OllivanderDaoImpl();

    private static class OllivanderServiceHolder {
        private static OllivanderService instance = new OllivanderService();
    }

    public static OllivanderService getInstance() {
        return OllivanderServiceHolder.instance;
    }

    public OllivanderService() {

    }

    public List<Ollivander> listAllOllivander() {

        return ollivanderDaoImpl.listAllOllivander();
    }
}
