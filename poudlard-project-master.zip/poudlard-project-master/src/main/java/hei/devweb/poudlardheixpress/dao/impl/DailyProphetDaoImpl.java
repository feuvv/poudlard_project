package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.dao.DailyProphetDao;
import hei.devweb.poudlardheixpress.entities.DailyProphet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DailyProphetDaoImpl implements DailyProphetDao {
    @Override
    public List<DailyProphet> listAllDailyProphet() {
        String sqlQuery = "SELECT * FROM dailyprophet ORDER BY datepub_news";
        List<DailyProphet> news = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try(Statement statement = connection.createStatement()) {
                try(ResultSet resultSet = statement.executeQuery(sqlQuery)){
                    while (resultSet.next()) {
                        news.add(new DailyProphet(resultSet.getInt("id_news"),
                                resultSet.getString("titre_news"),
                                resultSet.getString("article_news"),
                                resultSet.getString("rubrique_news"),
                                resultSet.getString("auteur_news"),
                                resultSet.getString("datepub_news")
                        ));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return news;
    }
}
