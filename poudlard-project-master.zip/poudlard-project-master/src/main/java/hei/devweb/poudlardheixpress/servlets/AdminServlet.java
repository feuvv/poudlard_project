package hei.devweb.poudlardheixpress.servlets;

import hei.devweb.poudlardheixpress.entities.Admin;
import hei.devweb.poudlardheixpress.entities.FleuryBott;
import hei.devweb.poudlardheixpress.entities.Register;
import hei.devweb.poudlardheixpress.services.AdminService;
import hei.devweb.poudlardheixpress.services.FleuryBottService;
import hei.devweb.poudlardheixpress.services.RegisterServices;
import hei.devweb.poudlardheixpress.utils.PasswordUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin")
public class AdminServlet extends AbstractServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String mail = request.getParameter("mail");
        String mdp = request.getParameter("mdp");
        String pseudo = request.getParameter("pseudo");
        String role = request.getParameter("role");

        String mdpHash = PasswordUtils.generatePwd(mdp);
        Register userToAdd = new Register(null, prenom, nom, pseudo ,mail, mdpHash, role);
        AdminService.getInstance().addUser(userToAdd);
        response.sendRedirect(String.format("/admin"));



    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContextTemplateResolver resolver = generateTemplateResolver(request, response);
        resolver.setPrefix("/WEB-INF/templates/profil/");
        TemplateEngine engine = generateTemplateEngine(request, response);
        engine.setTemplateResolver(resolver);

        WebContext context = new WebContext(request, response, request.getServletContext());

        List<Admin> listUsers = AdminService.getInstance().listAllUsers();
        context.setVariable("users", listUsers);
        engine.process("admin", context, response.getWriter());

    }
}
