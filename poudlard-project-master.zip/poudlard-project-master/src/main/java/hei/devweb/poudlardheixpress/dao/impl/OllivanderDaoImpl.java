package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.dao.OllivanderDao;
import hei.devweb.poudlardheixpress.entities.Ollivander;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OllivanderDaoImpl implements OllivanderDao {

    @Override
    public List<Ollivander> listAllOllivander() {
        String sqlQuery = "SELECT * FROM ollivander ORDER BY titre_ol";
        List<Ollivander> lists = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try(Statement statement = connection.createStatement()) {
                try(ResultSet resultSet = statement.executeQuery(sqlQuery)){
                    while (resultSet.next()) {
                        lists.add(new Ollivander(resultSet.getInt("id_ol"),
                                resultSet.getString("titre_ol"),
                                resultSet.getString("image_ol"),
                                resultSet.getDouble("prix_ol"),
                                resultSet.getString("description_ol"),
                                resultSet.getString("type_ol")
                        ));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lists;
    }
}
