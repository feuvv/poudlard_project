package hei.devweb.poudlardheixpress.dao.impl;

import java.io.IOException;
import java.sql.*;

public class ChangePwdDaoImpl {

    public void change(String mdp, String identifiant) throws IOException {
        String sqlQuery1 = "UPDATE communaute SET mdp_com=? WHERE identifiant_com=?";
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sqlQuery1, Statement.RETURN_GENERATED_KEYS)) {
                statement.setString(1, mdp);
                statement.setString(2, identifiant);
                statement.executeUpdate();

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
