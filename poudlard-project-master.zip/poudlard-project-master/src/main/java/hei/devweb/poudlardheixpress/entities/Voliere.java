package hei.devweb.poudlardheixpress.entities;

public class Voliere {
    private Integer id_vol;
    private String com_vol;
    private Integer pseudo_vol;
    private Register register;

    public Voliere(Integer id, String com, Integer pseudo, Register register) {
        super();
        this.id_vol = id;
        this.com_vol = com;
        this.pseudo_vol = pseudo;
        this.register = register;
    }

    public Integer getId_vol() {
        return id_vol;
    }

    public void setId_vol(Integer id_vol) {
        this.id_vol = id_vol;
    }

    public String getCom_vol() {
        return com_vol;
    }

    public void setCom_vol(String com_vol) {
        this.com_vol = com_vol;
    }

    public Integer getPseudo_vol() {
        return pseudo_vol;
    }

    public void setPseudo_vol(Integer pseudo_vol) {
        this.pseudo_vol = pseudo_vol;
    }

    public Register getRegister() {
        return register;
    }

    public void setRegister(Register register) {
        this.register = register;
    }
}
