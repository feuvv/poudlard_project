package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.dao.QuidditchDao;
import hei.devweb.poudlardheixpress.entities.Quidditch;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class QuidditchDaoImpl implements QuidditchDao {
    @Override
    public List<Quidditch> listAllQuidditch() {
        String sqlQuery = "SELECT * FROM quidditch ORDER BY id_qd";
        List<Quidditch> shopQuidditch = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try(Statement statement = connection.createStatement()) {
                try(ResultSet resultSet = statement.executeQuery(sqlQuery)){
                    while (resultSet.next()) {
                        shopQuidditch.add(new Quidditch(resultSet.getInt("id_qd"),
                                resultSet.getString("titre_qd"),
                                resultSet.getString("image_qd"),
                                resultSet.getString("description_qd"),
                                resultSet.getInt("prix_qd")
                        ));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return shopQuidditch;
    }
}
