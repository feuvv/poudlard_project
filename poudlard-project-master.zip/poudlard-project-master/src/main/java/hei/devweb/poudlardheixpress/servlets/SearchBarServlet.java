package hei.devweb.poudlardheixpress.servlets;

import hei.devweb.poudlardheixpress.entities.FleuryBott;
import hei.devweb.poudlardheixpress.entities.MadameGuipuire;
import hei.devweb.poudlardheixpress.entities.Ollivander;
import hei.devweb.poudlardheixpress.entities.Quidditch;
import hei.devweb.poudlardheixpress.services.SearchBarService;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/search")
public class SearchBarServlet extends AbstractServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContextTemplateResolver resolver = generateTemplateResolver(request, response);
        resolver.setPrefix("/WEB-INF/templates/marketplace/");

        TemplateEngine engine = generateTemplateEngine(request, response);
        engine.setTemplateResolver(resolver);
        WebContext context = new WebContext(request, response, request.getServletContext());

        String search = request.getParameter("searchTool");
        try {

            List<Ollivander> listOf1 = SearchBarService.getInstance().listSearchOllivander(search);
            if(listOf1!=null){
                context.setVariable("listResult1", listOf1);
            }
            List<MadameGuipuire> listOf2 = SearchBarService.getInstance().listSearchMadameGuipire(search);
            if(listOf2!=null){
                context.setVariable("listResult2", listOf2);
            }
            List<FleuryBott> listOf3 = SearchBarService.getInstance().listSearchFleuryBott(search);
            if(listOf3!=null){
                context.setVariable("listResult3", listOf3);
            }
            List<Quidditch> listOf4 = SearchBarService.getInstance().listSearchQuidditch(search);
            if(listOf4!=null){
                context.setVariable("listResult4", listOf4);
            }
            if(listOf1==null && listOf2==null && listOf3==null && listOf4==null){
                String nothing="rien";
                context.setVariable("nothing", nothing);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        engine.process("searchresult", context, response.getWriter());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


    }
}