package hei.devweb.poudlardheixpress.entities;

public class MadameGuipuire {
    private Integer id_gu;
    private String titre_gu;
    private String image_gu;
    private String description_gu;
    private int prix_gu;

    public MadameGuipuire(Integer id, String titre, String image, String description, int prix) {
        super();
        this.id_gu = id;
        this.titre_gu = titre;
        this.image_gu = image;
        this.description_gu = description;
        this.prix_gu = prix;
    }


    public Integer getId_gu() {
        return id_gu;
    }

    public void setId_gu(Integer id_gu) {
        this.id_gu = id_gu;
    }

    public String getTitre_gu() {
        return titre_gu;
    }

    public void setTitre_gu(String titre_gu) {
        this.titre_gu = titre_gu;
    }

    public String getImage_gu() {
        return image_gu;
    }

    public void setImage_gu(String image_gu) {
        this.image_gu = image_gu;
    }

    public String getDescription_gu() {
        return description_gu;
    }

    public void setDescription_gu(String description_gu) {
        this.description_gu = description_gu;
    }

    public int getPrix_gu() {
        return prix_gu;
    }

    public void setPrix_gu(int prix_gu) {
        this.prix_gu = prix_gu;
    }
}
