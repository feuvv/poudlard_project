package hei.devweb.poudlardheixpress.servlets;

import hei.devweb.poudlardheixpress.services.RegisterServices;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet
public class CheckServlet extends AbstractServlet {


    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContextTemplateResolver resolver = generateTemplateResolver(request, response);
        resolver.setPrefix("/WEB-INF/templates/register/");

        TemplateEngine engine = generateTemplateEngine(request, response);
        engine.setTemplateResolver(resolver);

        List<String> pseudos = RegisterServices.getInstance().ListByPSeudo();
        response.getWriter().print(pseudos);


    }

}