package hei.devweb.poudlardheixpress.dao;

import hei.devweb.poudlardheixpress.entities.Quidditch;

import java.util.List;

public interface QuidditchDao {
    public List<Quidditch> listAllQuidditch();
}
