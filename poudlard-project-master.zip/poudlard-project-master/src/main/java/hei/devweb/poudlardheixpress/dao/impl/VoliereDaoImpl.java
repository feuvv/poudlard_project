package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.dao.VoliereDao;
import hei.devweb.poudlardheixpress.entities.Register;
import hei.devweb.poudlardheixpress.entities.Voliere;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class VoliereDaoImpl implements VoliereDao {
    @Override
    public List<Voliere> listAllVoliere() {
        String sqlQuery = "SELECT * FROM voliere\n" +  "" +
                "JOIN communaute ON pseudo_vol = id_com\n " +
                "ORDER BY id_vol";
        List<Voliere> volieres = new ArrayList<>();
        try(Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery(sqlQuery)) {
                    while(resultSet.next()) {
                        Register register = new Register(resultSet.getInt("id_com"),
                                resultSet.getString("nom_com"),
                                resultSet.getString("prenom_com"),
                                resultSet.getString("identifiant_com"),
                                resultSet.getString("mdp_com"),
                                resultSet.getString("pseudo_com"),
                                resultSet.getString("role_com"));
                        volieres.add(new Voliere(resultSet.getInt("id_vol"),
                                resultSet.getString("com_vol"),
                                resultSet.getInt("pseudo_vol"),
                                register));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return volieres;
    }
}
