package hei.devweb.poudlardheixpress.dao;

import hei.devweb.poudlardheixpress.entities.Admin;

import java.util.List;

public interface AdminDao {
    public List<Admin> listAllUsers();

    public void deleteUser(Integer userId);
}
