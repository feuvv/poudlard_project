package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.ConnexionDao;
import hei.devweb.poudlardheixpress.dao.impl.ConnexionDaoImpl;
import hei.devweb.poudlardheixpress.entities.Connexion;


public class ConnexionService {
    private ConnexionDao connexionDaoImpl = new ConnexionDaoImpl();

    private static class ConnexionServiceHolder {
        private static ConnexionService instance = new ConnexionService();
    }

    public static ConnexionService getInstance() {
        return ConnexionService.ConnexionServiceHolder.instance;
    }

    public ConnexionService() {
    }

    public Connexion listAllConnexion() {
        return connexionDaoImpl.getConnexion("identifiant_com","mdp_com");
    }

    public Connexion verifConnexion(String identifiant, String motDePasse){

        if(identifiant!= null){
            Connexion  connexion =  connexionDaoImpl.getConnexion(motDePasse,identifiant);
            if(connexion != null){
               if(connexion.getMdp().equals(motDePasse)){
                   return connexion;
               }else{
                   javax.swing.JOptionPane.showMessageDialog(null,"Your mdp is not in our DB");
                   throw new IllegalArgumentException("Your mdp is not in our DB");
               }
            }
            else{
                javax.swing.JOptionPane.showMessageDialog(null,"Your id is not in our DB");
                throw new IllegalArgumentException("Your id is not in our DB");
            }
        }
        else{
            javax.swing.JOptionPane.showMessageDialog(null,"A connexion must have an id");
            throw new IllegalArgumentException("A connexion must have an id");
        }
    }
}

