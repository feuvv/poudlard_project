package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.dao.ConnexionDao;
import hei.devweb.poudlardheixpress.entities.Connexion;
import hei.devweb.poudlardheixpress.services.GetHashService;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static hei.devweb.poudlardheixpress.utils.PasswordUtils.validerMotDePasse;

public class ConnexionDaoImpl implements ConnexionDao {

    public List<Connexion> listAllConnexion() {
        String sqlQuery = "SELECT * FROM communaute WHERE identifiant_com=? AND mdp_com=? AND id_com=?";
        List<Connexion> connexions = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try(Statement statement = connection.createStatement()) {
                try(ResultSet resultSet = statement.executeQuery(sqlQuery)){
                    while (resultSet.next()) {
                        connexions.add(new Connexion(
                                resultSet.getInt("id_com"),
                                resultSet.getString("identifiant_com"),
                                resultSet.getString(("mdp_com"))
                        ));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return connexions;
    }

    @Override
    public Connexion getConnexion(String mdp, String identifiant){
        String sqlQuery = "SELECT * FROM communaute WHERE identifiant_com=?";
        GetHashService getHashService = new GetHashService();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
                statement.setString(1,identifiant);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        if (validerMotDePasse(mdp,resultSet.getString("mdp_com"))) {
                            return new Connexion(resultSet.getInt("id_com"), resultSet.getString("identifiant_com"), resultSet.getString("mdp_com"));
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Connexion mapConnexion(ResultSet resultSetRow) throws SQLException {
        return new Connexion(
                resultSetRow.getInt("id_com"),
                resultSetRow.getString("identifiant_com"),
                resultSetRow.getString("mdp_com")
        );
    }
}
