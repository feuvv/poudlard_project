package hei.devweb.poudlardheixpress.entities;

public class Register {

    private String prenom;
    private String nom;
    private String pseudo;
    private String mail;
    private String mdp;
    private String role;
    private Integer id;

    public Register(Integer id, String prenom, String nom,String pseudo, String mail, String mdp, String role){
        this.mail = mail;
        this.mdp = mdp;
        this.nom = nom;
        this.prenom = prenom;
        this.pseudo = pseudo;
        this.id = id;
        this.role = role;
    }

    public Register(String pseudo){
        this.pseudo = pseudo;
    }

    public Integer getId() { return id;}
    public void setId(Integer id){this.id = id;}

    public String getPrenom() {
        return prenom;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getMail() {
        return mail;
    }
    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPseudo() {
        return pseudo;
    }
    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public String getMdp() {
        return mdp;
    }
    public void setMdp(String mdp) {
        this.mdp = mdp;
    }

    public String getRole() { return role;}
    public void setRole(String role){this.role = role;}




}
