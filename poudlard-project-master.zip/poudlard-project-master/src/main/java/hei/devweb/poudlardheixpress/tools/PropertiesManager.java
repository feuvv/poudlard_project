package hei.devweb.poudlardheixpress.tools;

import java.io.IOException;
import java.util.Properties;

public class PropertiesManager {

    Properties prop = new Properties();


    public PropertiesManager(String configurationFileName) throws IOException {
        prop.load(PropertiesManager.class.getResourceAsStream("/"+configurationFileName+".properties"));
    }

    public String readProperty(String clef){
        return prop.getProperty(clef);
    }
}
