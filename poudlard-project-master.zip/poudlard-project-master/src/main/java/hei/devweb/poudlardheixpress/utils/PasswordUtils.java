package hei.devweb.poudlardheixpress.utils;

import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;

public class PasswordUtils {
    private static final int LONGUEUR_SEL = 128;
    private static final int LONGUEUR_HASH = 128;
    private static final int NOMBRE_ITERATIONS = 5;
    private static final int MEMOIRE = 65536;
    private static final int PARALLELISME = 1;
    public static Argon2 instancierArgon2() {
        return Argon2Factory.create(Argon2Factory.Argon2Types.ARGON2i, LONGUEUR_SEL,
                LONGUEUR_HASH);
    }
    public static String generatePwd(String pwd) {
        return instancierArgon2().hash(NOMBRE_ITERATIONS, MEMOIRE, PARALLELISME,
                pwd);
    }
    public static boolean validerMotDePasse(String motDePasse, String hashCorrect) {
        return instancierArgon2().verify(hashCorrect, motDePasse);
    }

}
