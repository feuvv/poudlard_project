package hei.devweb.poudlardheixpress.entities;

public class Admin {
    private Integer id_com;
    private String prenom_com;
    private String nom_com;
    private String pseudo_com;
    private String identifiant_com;
    private String mdp_com;
    private String role_com;

    public Admin(Integer id, String prenom, String nom, String pseudo, String identifiant, String mdp, String role) {
        super();
        this.id_com = id;
        this.prenom_com = prenom;
        this.nom_com = nom;
        this.pseudo_com = pseudo;
        this.identifiant_com = identifiant;
        this.mdp_com = mdp;
        this.role_com = role;
    }
    public Admin(Integer id, String prenom, String nom, String pseudo, String identifiant, String role) {
        super();
        this.id_com = id;
        this.prenom_com = prenom;
        this.nom_com = nom;
        this.pseudo_com = pseudo;
        this.identifiant_com = identifiant;
        this.role_com = role;
    }

    public Integer getId_com() {
        return id_com;
    }

    public void setId_com(Integer id_com) {
        this.id_com = id_com;
    }

    public String getPrenom_com() {
        return prenom_com;
    }

    public void setPrenom_com(String prenom_com) {
        this.prenom_com = prenom_com;
    }

    public String getNom_com() {
        return nom_com;
    }

    public void setNom_com(String nom_com) {
        this.nom_com = nom_com;
    }

    public String getPseudo_com() {
        return pseudo_com;
    }

    public void setPseudo_com(String pseudo_com) {
        this.pseudo_com = pseudo_com;
    }

    public String getIdentifiant_com() {
        return identifiant_com;
    }

    public void setIdentifiant_com(String identifiant_com) {
        this.identifiant_com = identifiant_com;
    }

    public String getMdp_com() {
        return mdp_com;
    }

    public void setMdp_com(String mdp_com) {
        this.mdp_com = mdp_com;
    }


    public String getRole_com() {
        return role_com;
    }

    public void setRole_com(String role_com) {
        this.role_com = role_com;
    }
}
