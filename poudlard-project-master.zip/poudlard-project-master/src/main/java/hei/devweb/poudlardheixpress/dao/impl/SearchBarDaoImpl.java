package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.entities.FleuryBott;
import hei.devweb.poudlardheixpress.entities.MadameGuipuire;
import hei.devweb.poudlardheixpress.entities.Ollivander;
import hei.devweb.poudlardheixpress.entities.Quidditch;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SearchBarDaoImpl {

    public List<Ollivander> getOllivander(String search) throws SQLException {
        String sqlQuery = "SELECT * FROM ollivander WHERE titre_ol LIKE ? ";
        List<Ollivander> searchs = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
                statement.setString(1,  '%'+search+'%');
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        searchs.add(new Ollivander(
                                resultSet.getInt("id_ol"),
                                resultSet.getString("titre_ol"),
                                resultSet.getString("image_ol"),
                                resultSet.getDouble("prix_ol"),
                                resultSet.getString("description_ol"),
                                resultSet.getString("type_ol")));
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return searchs;
    }
    public List<MadameGuipuire> getMadameGuipire(String search) throws SQLException {
        String sqlQuery = "SELECT * FROM madameguipuire WHERE titre_gu LIKE ? ";
        List<MadameGuipuire> searchs = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
                statement.setString(1,  '%'+search+'%');
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        searchs.add(new MadameGuipuire(
                                resultSet.getInt("id_gu"),
                                resultSet.getString("titre_gu"),
                                resultSet.getString("image_gu"),
                                resultSet.getString("description_gu"),
                                resultSet.getInt("prix_gu")));
                        // le constructeur Madame Guipuire et son utilisation cf au dessus dans le MEME ORDRE
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return searchs;
    }
    public List<FleuryBott> getFleuryBott(String search) throws SQLException {
        String sqlQuery = "SELECT * FROM fleurybott WHERE titre_livre LIKE ? ";
        List<FleuryBott> searchs = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
                statement.setString(1, '%'+search+'%');
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        searchs.add(new FleuryBott(
                                resultSet.getInt("id_livre"),
                                resultSet.getString("titre_livre"),
                                resultSet.getString("type_livre"),
                                resultSet.getString("image_livre"),
                                resultSet.getDouble("prix_livre"),
                                resultSet.getString("auteur_livre"),
                                resultSet.getString("description_livre")));
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return searchs;
    }
    public List<Quidditch> getQuidditch(String search) throws SQLException {
        String sqlQuery = "SELECT * FROM quidditch WHERE titre_qd LIKE ?";
        List<Quidditch> searchs = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
                statement.setString(1, '%'+search+'%');
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        searchs.add(new Quidditch(
                                resultSet.getInt("id_qd"),
                                resultSet.getString("titre_qd"),
                                resultSet.getString("image_qd"),
                                resultSet.getString("description_qd"),
                                resultSet.getInt("prix_qd")));
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return searchs;
    }

}