package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.impl.FleuryBottDaoImpl;
import hei.devweb.poudlardheixpress.entities.FleuryBott;

import java.util.List;

public class FleuryBottService {
    private FleuryBottDaoImpl fleuryBottDaoImpl = new FleuryBottDaoImpl();

    private static class FleuryBottServiceHolder {
        private static FleuryBottService instance = new FleuryBottService();
    }

    public static FleuryBottService getInstance() {
        return FleuryBottService.FleuryBottServiceHolder.instance;
    }

    public FleuryBottService() {

    }

    public List<FleuryBott> listAllFleuryBott() {

        return fleuryBottDaoImpl.listAllFleuryBott();
    }
}
