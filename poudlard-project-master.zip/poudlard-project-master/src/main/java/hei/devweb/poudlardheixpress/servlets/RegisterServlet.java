package hei.devweb.poudlardheixpress.servlets;

import hei.devweb.poudlardheixpress.entities.Register;
import hei.devweb.poudlardheixpress.services.RegisterServices;
import hei.devweb.poudlardheixpress.utils.PasswordUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends AbstractServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String mail = request.getParameter("mail");
        String mdp = request.getParameter("mdp");
        String pseudo = request.getParameter("pseudo");
        String role = request.getParameter("role");

        String mdpHash = PasswordUtils.generatePwd(mdp);
        Register userToAdd = new Register(null, prenom, nom, pseudo ,mail, mdpHash, role);
        Register register = RegisterServices.getInstance().addUser(userToAdd);
        response.sendRedirect(String.format("/home"));

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContextTemplateResolver resolver = generateTemplateResolver(request, response);
        resolver.setPrefix("/WEB-INF/templates/register/");

        TemplateEngine engine = generateTemplateEngine(request, response);
        engine.setTemplateResolver(resolver);

        WebContext context = new WebContext(request, response, request.getServletContext());
        engine.process("register", context, response.getWriter());
    }
}
