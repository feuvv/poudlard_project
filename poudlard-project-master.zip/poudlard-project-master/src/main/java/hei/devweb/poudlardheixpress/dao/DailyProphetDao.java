package hei.devweb.poudlardheixpress.dao;

import hei.devweb.poudlardheixpress.entities.DailyProphet;

import java.util.List;

public interface DailyProphetDao {
    public List<DailyProphet> listAllDailyProphet();
}
