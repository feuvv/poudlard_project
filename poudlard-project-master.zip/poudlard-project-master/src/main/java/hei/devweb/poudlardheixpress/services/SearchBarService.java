package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.impl.SearchBarDaoImpl;
import hei.devweb.poudlardheixpress.entities.FleuryBott;
import hei.devweb.poudlardheixpress.entities.MadameGuipuire;
import hei.devweb.poudlardheixpress.entities.Ollivander;
import hei.devweb.poudlardheixpress.entities.Quidditch;

import java.sql.SQLException;
import java.util.List;

public class SearchBarService {
    private SearchBarDaoImpl searchBarDao = new SearchBarDaoImpl();

    private static class SearchBarServiceHolder {
        private static SearchBarService instance = new SearchBarService();
    }

    public static SearchBarService getInstance(){
        return SearchBarServiceHolder.instance;
    }
    public SearchBarService(){

    }

    public List<Ollivander> listSearchOllivander(String search) throws SQLException {

        return searchBarDao.getOllivander(search);
    }
    public List<MadameGuipuire> listSearchMadameGuipire(String search) throws SQLException {

        return searchBarDao.getMadameGuipire(search);
    }
    public List<Quidditch> listSearchQuidditch(String search) throws SQLException {

        return searchBarDao.getQuidditch(search);
    }
    public List<FleuryBott> listSearchFleuryBott(String search) throws SQLException {

        return searchBarDao.getFleuryBott(search);
    }
}
