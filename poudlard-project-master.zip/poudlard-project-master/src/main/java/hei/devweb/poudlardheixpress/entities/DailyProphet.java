package hei.devweb.poudlardheixpress.entities;

public class DailyProphet {
    private Integer id_news;
    private String titre_news;
    private String article_news;
    private String rubrique_news;
    private String auteur_news;
    private String datepub_news;

    public DailyProphet(Integer id, String titre, String article, String rubrique, String auteur, String datepub) {
        super();
        this.id_news=id;
        this.titre_news=titre;
        this.article_news=article;
        this.rubrique_news=rubrique;
        this.auteur_news=auteur;
        this.datepub_news=datepub;
    }

    public Integer getId_news() {
        return id_news;
    }

    public void setId_news(Integer id_news) {
        this.id_news = id_news;
    }

    public String getTitre_news() {
        return titre_news;
    }

    public void setTitre_news(String titre_news) {
        this.titre_news = titre_news;
    }

    public String getArticle_news() {
        return article_news;
    }

    public void setArticle_news(String article_news) {
        this.article_news = article_news;
    }

    public String getAuteur_news() {
        return auteur_news;
    }

    public void setAuteur_news(String auteur_news) {
        this.auteur_news = auteur_news;
    }

    public String getRubrique_news() {
        return rubrique_news;
    }

    public void setRubrique_news(String rubrique_news) {
        this.rubrique_news = rubrique_news;
    }

    public String getDatepub_news() {
        return datepub_news;
    }

    public void setDatepub_news(String datepub_news) {
        this.datepub_news = datepub_news;
    }
}
