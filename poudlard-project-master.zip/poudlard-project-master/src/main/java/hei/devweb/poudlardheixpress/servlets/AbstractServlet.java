package hei.devweb.poudlardheixpress.servlets;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.extras.java8time.dialect.Java8TimeDialect;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AbstractServlet")
public class AbstractServlet extends HttpServlet {
    public ServletContextTemplateResolver generateTemplateResolver(HttpServletRequest request, HttpServletResponse response) throws IOException {
        ServletContextTemplateResolver resolver =
                new ServletContextTemplateResolver(request.getServletContext());

        resolver.setSuffix(".html");
        resolver.setTemplateMode(TemplateMode.HTML);
        resolver.setCharacterEncoding("UTF-8");

        return resolver;
    }

    public TemplateEngine generateTemplateEngine(HttpServletRequest request, HttpServletResponse response) throws IOException {

        TemplateEngine engine = new TemplateEngine();
        engine.setTemplateResolver(generateTemplateResolver(request, response));
        engine.addDialect(new Java8TimeDialect());

        return engine;
    }
}