package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.impl.AdminDaoImpl;
import hei.devweb.poudlardheixpress.dao.impl.FleuryBottDaoImpl;
import hei.devweb.poudlardheixpress.entities.Admin;
import hei.devweb.poudlardheixpress.entities.FleuryBott;
import hei.devweb.poudlardheixpress.entities.Register;

import java.util.List;

public class AdminService {
    private AdminDaoImpl adminDaoImpl = new AdminDaoImpl();

    private static class AdminServiceHolder {
        private static AdminService instance = new AdminService();
    }

    public static AdminService getInstance() {
        return AdminService.AdminServiceHolder.instance;
    }

    public AdminService() {

    }

    public List<Admin> listAllUsers() {

        return adminDaoImpl.listAllUsers();
    }
    public Register addUser (Register user){
        return adminDaoImpl.addUser(user);
    }

    public void deleteUser(Integer userId) {
        adminDaoImpl.deleteUser(userId);
    }

}
