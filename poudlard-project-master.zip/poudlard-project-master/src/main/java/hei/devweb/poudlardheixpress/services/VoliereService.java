package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.impl.VoliereDaoImpl;
import hei.devweb.poudlardheixpress.entities.Voliere;

import java.util.List;

public class VoliereService {
    private VoliereDaoImpl voliereDaoImpl = new VoliereDaoImpl();

    private static class VoliereServiceHolder {
        private final static VoliereService instance = new VoliereService();
    }

    public static VoliereService getInstance() {
        return VoliereServiceHolder.instance;
    }

    public VoliereService() {

    }

    public List<Voliere> listAllVoliere() {
        return voliereDaoImpl.listAllVoliere();
    }
}
