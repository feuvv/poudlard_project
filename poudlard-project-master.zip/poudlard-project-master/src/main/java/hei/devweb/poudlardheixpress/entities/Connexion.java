package hei.devweb.poudlardheixpress.entities;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Connexion {
    private String identifiant; //Adresse mail
    private String mdp;
    private int id;

    public Connexion(int id, String identifiant, String mdp) {
        this.identifiant=identifiant;
        this.mdp=mdp;
        this.id=id;
    }

    public Connexion(String mdp_com, String identifiant_com) {
        this.mdp=mdp_com;
        this.identifiant=identifiant_com;
    }


    public String getIdentifiant(){
        return identifiant;
    }

    public void setIdentifiant(String id) {
        this.identifiant=id;
    }

    public String getMdp(){
        return mdp;
    }

    public void setMdp(String mdp){
        this.mdp=mdp;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id=id;
    }

    private String code;
}
