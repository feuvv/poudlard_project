package hei.devweb.poudlardheixpress.filters;

import hei.devweb.poudlardheixpress.dao.impl.ConnexionDaoImpl;
import hei.devweb.poudlardheixpress.entities.Connexion;
import org.thymeleaf.TemplateEngine;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebFilter("/poudlard")
public class MarketPlaceFilter implements Filter {


    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        if (request.getSession().getAttribute("connecte") == null){
            HttpServletResponse httpResponse = (HttpServletResponse) response;
            response.sendRedirect("/marketplace");
            return;
        }
        filterChain.doFilter( request, response );

    }

    @Override
    public void destroy() {


    }
}