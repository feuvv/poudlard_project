package hei.devweb.poudlardheixpress.entities;

public class Ollivander {
    private Integer id_ol;
    private String titre_ol;
    private String image_ol;
    private double prix_ol;
    private String description_ol;
    private String type_ol;

    public Ollivander(Integer id, String title, String image, double prix, String description, String type) {
        super();
        this.id_ol = id;
        this.titre_ol = title;
        this.image_ol = image;
        this.prix_ol = prix;
        this.description_ol = description;
        this.type_ol = type;
    }


    public Integer getId_ol() {
        return id_ol;
    }

    public void setId_ol(Integer id_ol) {
        this.id_ol = id_ol;
    }

    public String getTitre_ol() {
        return titre_ol;
    }

    public void setTitre_ol(String titre_ol) {
        this.titre_ol = titre_ol;
    }

    public String getImage_ol() {
        return image_ol;
    }

    public void setImage_ol(String image_ol) {
        this.image_ol = image_ol;
    }

    public double getPrix_ol() {
        return prix_ol;
    }

    public void setPrix_ol(double prix_ol) {
        this.prix_ol = prix_ol;
    }

    public String getDescription_ol() {
        return description_ol;
    }

    public void setDescription_ol(String description_ol) {
        this.description_ol = description_ol;
    }

    public String getType_ol() {
        return type_ol;
    }

    public void setType_ol(String type_ol) {
        this.type_ol = type_ol;
    }
}
