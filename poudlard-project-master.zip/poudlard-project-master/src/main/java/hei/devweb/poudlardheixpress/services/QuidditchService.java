package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.impl.QuidditchDaoImpl;
import hei.devweb.poudlardheixpress.entities.Quidditch;

import java.util.List;

public class QuidditchService {

    private QuidditchDaoImpl quidditchDaoImpl = new QuidditchDaoImpl();

    private static class QuidditchServiceHolder {
        private static QuidditchService instance = new QuidditchService();
    }

    public static QuidditchService getInstance() {
        return QuidditchService.QuidditchServiceHolder.instance;
    }

    public QuidditchService() {

    }

    public List<Quidditch> listAllQuidditch() {

        return quidditchDaoImpl.listAllQuidditch();
    }
}
