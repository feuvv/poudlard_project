package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.dao.MadameGuipuireDao;
import hei.devweb.poudlardheixpress.entities.MadameGuipuire;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MadameGuipuireDaoImpl implements MadameGuipuireDao {
    @Override
    public List<MadameGuipuire> listAllMadameGuipuire() {
        String sqlQuery = "SELECT * FROM madameguipuire ORDER BY id_gu";
        List<MadameGuipuire> clothes = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery(sqlQuery)) {
                    while (resultSet.next()) {
                        clothes.add(new MadameGuipuire(resultSet.getInt("id_gu"),
                                resultSet.getString("titre_gu"),
                                resultSet.getString("image_gu"),
                                resultSet.getString("description_gu"),
                                resultSet.getInt("prix_gu")
                        ));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return clothes;
    }
}
