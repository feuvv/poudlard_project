package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.impl.ChangePwdDaoImpl;

import java.io.IOException;


public class ChangePwdService {

    private ChangePwdDaoImpl changePwdDao = new ChangePwdDaoImpl();

    private static class ChangePwdServiceHolder {
        private static ChangePwdService instance = new ChangePwdService();
    }

    public static ChangePwdService getInstance(){
        return ChangePwdService.ChangePwdServiceHolder.instance;
    }

    public void setChangePwdDao(String mdp, String id) throws IOException {
        changePwdDao.change(mdp, id);
    }
}
