package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.dao.FleuryBottDao;
import hei.devweb.poudlardheixpress.entities.FleuryBott;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class FleuryBottDaoImpl implements FleuryBottDao {

    @Override
    public List<FleuryBott> listAllFleuryBott() {
        String sqlQuery = "SELECT * FROM fleurybott ORDER BY id_livre";
        List<FleuryBott> livres = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try(Statement statement = connection.createStatement()) {
                try(ResultSet resultSet = statement.executeQuery(sqlQuery)){
                    while (resultSet.next()) {
                        livres.add(new FleuryBott(resultSet.getInt("id_livre"),
                                resultSet.getString("titre_livre"),
                                resultSet.getString("type_livre"),
                                resultSet.getString("image_livre"),
                                resultSet.getDouble("prix_livre"),
                                resultSet.getString("auteur_livre"),
                                resultSet.getString("description_livre")
                        ));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return livres;
    }
}
