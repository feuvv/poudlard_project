package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.impl.MadameGuipuireDaoImpl;
import hei.devweb.poudlardheixpress.entities.MadameGuipuire;

import java.util.List;

public class MadameGuipuireService {
    private MadameGuipuireDaoImpl madameGuipuireDaoImpl = new MadameGuipuireDaoImpl();

    private static class MadameGuipuireServiceHolder {
        private static MadameGuipuireService instance = new MadameGuipuireService();
    }

    public static MadameGuipuireService getInstance() {
        return MadameGuipuireService.MadameGuipuireServiceHolder.instance;
    }

    public MadameGuipuireService() {

    }

    public List<MadameGuipuire> listAllMadameGuipuire() {

        return madameGuipuireDaoImpl.listAllMadameGuipuire();
    }
}
