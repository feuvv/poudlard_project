package hei.devweb.poudlardheixpress.dao;

import hei.devweb.poudlardheixpress.entities.Connexion;

import java.util.List;

public interface ConnexionDao {
    public List<Connexion> listAllConnexion();

    public Connexion getConnexion(String identifiant_com,String mdp_com);

}
