package hei.devweb.poudlardheixpress.dao;

import hei.devweb.poudlardheixpress.entities.FleuryBott;

import java.util.List;

public interface FleuryBottDao {
    public List<FleuryBott> listAllFleuryBott();
}
