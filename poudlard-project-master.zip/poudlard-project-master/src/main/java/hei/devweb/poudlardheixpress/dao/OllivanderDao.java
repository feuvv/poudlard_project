package hei.devweb.poudlardheixpress.dao;

import hei.devweb.poudlardheixpress.entities.Ollivander;

import java.util.List;

public interface OllivanderDao {
    public List<Ollivander> listAllOllivander();
}
