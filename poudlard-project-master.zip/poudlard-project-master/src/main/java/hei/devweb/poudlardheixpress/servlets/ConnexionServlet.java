package hei.devweb.poudlardheixpress.servlets;

import hei.devweb.poudlardheixpress.dao.impl.ConnexionDaoImpl;
import hei.devweb.poudlardheixpress.entities.Connexion;
import hei.devweb.poudlardheixpress.services.GetHashService;
import hei.devweb.poudlardheixpress.utils.PasswordUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/connexion")
public class ConnexionServlet extends AbstractServlet {

    public static final String ACCES_PUBLIC = "/register";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        // GET PARAMETERS
        String identifiant=request.getParameter("identifiant_com");
        String mdp = request.getParameter("mdp_com");

        /* Récupération de la session depuis la requête*/
        HttpSession session = request.getSession();

        ConnexionDaoImpl connexionDao = new ConnexionDaoImpl();
        Connexion createdConnexion = connexionDao.getConnexion(mdp, identifiant);


       // CREATE A CONNEXION
        if (createdConnexion!=null){
            // REDIRECT TO DETAIL POUDLARD
            request.getSession().setAttribute("connecte",true);
            request.getSession().removeAttribute("Connexion-error-message");
            response.sendRedirect("/poudlard");
        }else{
            request.getSession().setAttribute("Connexion-error-message","Nom d'utilisateur ou mot de passe incorect");
            response.sendRedirect(request.getContextPath()+String.format(ACCES_PUBLIC));
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        String errorMessage = (String) request.getSession().getAttribute("connexion-error-message");
        request.getSession().removeAttribute("connexion-error-message");

        //C'est le bloc pour aller chercher la page HTML
        ServletContextTemplateResolver resolver =
                generateTemplateResolver(request, response);
        resolver.setPrefix("/WEB-INF/templates/register/");

        TemplateEngine engine = generateTemplateEngine(request, response);
        engine.setTemplateResolver(resolver);
        WebContext context = new WebContext(request, response, request.getServletContext());

        //Les variables
        context.setVariable("identifiant_com","id_com");
        context.setVariable("mdp_com","id_com");
        context.setVariable("errorMessage", errorMessage);
        engine.process("connexion", context, response.getWriter());
    }
}
