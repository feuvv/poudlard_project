package hei.devweb.poudlardheixpress.dao;

import hei.devweb.poudlardheixpress.entities.MadameGuipuire;

import java.util.List;

public interface MadameGuipuireDao {
    public List<MadameGuipuire> listAllMadameGuipuire();
}
