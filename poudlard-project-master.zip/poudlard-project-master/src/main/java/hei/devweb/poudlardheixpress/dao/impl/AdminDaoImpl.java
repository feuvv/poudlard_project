package hei.devweb.poudlardheixpress.dao.impl;

import hei.devweb.poudlardheixpress.dao.AdminDao;
import hei.devweb.poudlardheixpress.entities.Admin;
import hei.devweb.poudlardheixpress.entities.Register;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdminDaoImpl implements AdminDao {
    @Override
    public List<Admin> listAllUsers() {
        String sqlQuery = "SELECT * FROM communaute ORDER BY id_com";
        List<Admin> users = new ArrayList<>();
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try(Statement statement = connection.createStatement()) {
                try(ResultSet resultSet = statement.executeQuery(sqlQuery)){
                    while (resultSet.next()) {
                        users.add(new Admin(resultSet.getInt("id_com"),
                                resultSet.getString("prenom_com"),
                                resultSet.getString("nom_com"),
                                resultSet.getString("pseudo_com"),
                                resultSet.getString("identifiant_com"),
                                resultSet.getString("role_com")
                        ));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return users;
    }

    @Override
    public void deleteUser(Integer userId) {
        String sqlQuery = "DELETE FROM communaute WHERE id_com=?";
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
                statement.setInt(1, userId);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public Register addUser(Register user) {

        String sqlQuery1 = "INSERT INTO communaute(id_com, prenom_com, nom_com, pseudo_com, identifiant_com , mdp_com, role_com) VALUES(null ,?, ?, ?, ?, ?, ?);";
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sqlQuery1, Statement.RETURN_GENERATED_KEYS)) {
                statement.setString(1, user.getPrenom());
                statement.setString(2, user.getNom());
                statement.setString(3, user.getPseudo());
                statement.setString(4, user.getMail());
                statement.setString(5, user.getMdp());
                statement.setString(6, user.getRole());

                statement.executeUpdate();

                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        user.setId(generatedKeys.getInt(1));
                        return user;
                    }
                }
            }



        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


}
