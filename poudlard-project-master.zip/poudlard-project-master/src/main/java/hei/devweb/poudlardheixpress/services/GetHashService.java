package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.utils.PasswordUtils;

public class GetHashService {

        private static class GetHashServiceHolder {
            private static hei.devweb.poudlardheixpress.services.GetHashService instance = new hei.devweb.poudlardheixpress.services.GetHashService();
        }

        public static hei.devweb.poudlardheixpress.services.GetHashService getInstance(){
            return hei.devweb.poudlardheixpress.services.GetHashService.GetHashServiceHolder.instance;
        }

        public String getHashPwd(String pwd){
            return PasswordUtils.generatePwd(pwd);
        }


}
