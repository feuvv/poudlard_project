package hei.devweb.poudlardheixpress.services;

import hei.devweb.poudlardheixpress.dao.impl.RegisterDaoImpl;
import hei.devweb.poudlardheixpress.entities.Register;

import java.util.List;

public class RegisterServices {

    private RegisterDaoImpl userDao = new RegisterDaoImpl();

    private static class RegisterServiceHolder{
        private static RegisterServices instance = new RegisterServices();
    }

    public static RegisterServices getInstance(){
        return(RegisterServiceHolder.instance);
    }

    public RegisterServices(){}

    public Register addUser(Register user){
        return userDao.addUser(user);
    }

    public List<String> ListByPSeudo(){
        return userDao.verifyPseudo();
    }
}
