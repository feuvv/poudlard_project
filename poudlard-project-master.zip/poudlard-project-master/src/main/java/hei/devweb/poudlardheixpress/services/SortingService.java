package hei.devweb.poudlardheixpress.services;

import javax.servlet.http.HttpServletRequest;
import java.util.Random;

public class SortingService {

    private static class SortingServiceHolder {
        private static SortingService instance = new SortingService();
    }

    public static SortingService getInstance() {
        return SortingService.SortingServiceHolder.instance;
    }


    public String getHouse(HttpServletRequest request) {
        Random num = new Random();
        Integer n = num.nextInt(100);
        Integer compteur = 0;

            for (Integer i = 1; i < 13; i++) {
                String[] value = request.getParameterValues("question" + i + "");
                if (value[0] == null) {
                    compteur += n;
                }
                if ("choix1".equals(value[0])) {
                    compteur += 1;
                }
                if ("choix2".equals(value[0])) {
                    compteur += 4;
                }
                if ("choix3".equals(value[0])) {
                    compteur += 7;
                } else {
                    compteur += 15;
                }
            }

            String maison = "";
            if (compteur >= 0 && compteur < 95) {
                maison = "Poufsoufffle";
            }
            if (compteur >= 95 && compteur < 130) {
                maison = "Serdaigle";
            }
            if (compteur >= 130 && compteur < 180) {
                maison = "Gryffondor";
            }
            if (compteur >= 180) {
                maison = "Serpentard";
            }
            return maison;


    }
}


