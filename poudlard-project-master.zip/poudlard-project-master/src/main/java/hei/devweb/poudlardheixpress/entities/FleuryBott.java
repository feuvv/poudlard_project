package hei.devweb.poudlardheixpress.entities;

public class FleuryBott {
    private Integer id_livre;
    private String titre_livre;
    private String type_livre;
    private String image_livre;
    private double prix_livre;
    private String auteur_livre;
    private String description_livre;

    public FleuryBott(Integer id, String titre, String type, String image, double prix, String auteur, String description) {
        super();
        this.id_livre=id;
        this.titre_livre=titre;
        this.type_livre=type;
        this.image_livre=image;
        this.prix_livre=prix;
        this.auteur_livre=auteur;
        this.description_livre=description;
    }


    public Integer getId_livre() {
        return id_livre;
    }

    public void setId_livre(Integer id_livre) {
        this.id_livre = id_livre;
    }

    public String getTitre_livre() {
        return titre_livre;
    }

    public void setTitre_livre(String titre_livre) {
        this.titre_livre = titre_livre;
    }

    public String getType_livre() {
        return type_livre;
    }

    public void setType_livre(String type_livre) {
        this.type_livre = type_livre;
    }

    public String getImage_livre() {
        return image_livre;
    }

    public void setImage_livre(String image_livre) {
        this.image_livre = image_livre;
    }

    public double getPrix_livre() {
        return prix_livre;
    }

    public void setPrix_livre(double prix_livre) {
        this.prix_livre = prix_livre;
    }

    public String getAuteur_livre() {
        return auteur_livre;
    }

    public void setAuteur_livre(String auteur_livre) {
        this.auteur_livre = auteur_livre;
    }

    public String getDescription_livre() {
        return description_livre;
    }

    public void setDescription_livre(String description_livre) {
        this.description_livre = description_livre;
    }
}
