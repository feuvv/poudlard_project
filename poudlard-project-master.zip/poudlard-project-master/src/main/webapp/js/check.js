function verifPseudoJs() {
    var pseudo = document.getElementById("pseudo").value;
    if (pseudo === "") {
        alert("Merci de renseigner un pseudo");
    } else {
        let requete = new XMLHttpRequest();
        let url = "ws/register";
        requete.open("GET", url, true);
        requete.responseType = "json";

        requete.onload = function () {
            let pseudosList = this.response;
            let pseudoForm = document.getElementById("pseudo").value;

            let longList = pseudosList.size();
            console.log(pseudosList);
            for (i = 0; i < longList + 1; i++) {
                if (pseudosList[i] !== pseudoForm) {
                    document.getElementById("pseudo").style.backgroundColor = "#b4ffaf";
                    document.getElementById("messagePseudo").hidden = true;
                } else {
                    document.getElementById("pseudo").style.backgroundColor = "#ff5b58";
                    document.getElementById("messagePseudo").hidden = false;
                }

            }

            requete.send();
        }
    }
}

    var preOk, mailOk, mdpOk, mdpvOk;

    function prenomisEmpty() {
        if (document.getElementById("prenom").value === '') {
            document.getElementById("prenom").style.backgroundColor = "#ff5b58";
            document.getElementById("messagePrenom").style.backgroundColor = 'visible';
            return preOk = false;
        } else {
            document.getElementById("prenom").style.backgroundColor = "#b4ffaf";
            return preOk = true;
        }
    }

    function NomisEmpty() {
        //renseignement non obligatoire
        document.getElementById("nom").style.backgroundColor = "#b4ffaf";
    }

    function mailisEmpty() {
        if (document.getElementById("mail").value === '') {
            document.getElementById("mail").style.backgroundColor = "#ff5b58";
            return mailOk = false;
        } else {
            document.getElementById("mail").style.backgroundColor = "#b4ffaf";
            return mailOk = true;
        }
    }

    function mdpisEmpty() {
        if (document.getElementById("mdp").value !== '' && document.getElementById("mdp").value.length >= 4) {
            document.getElementById("mdp").style.backgroundColor = "#b4ffaf";
            return mdpOk = true;

        } else if (document.getElementById("mdp").value === '') {
            document.getElementById("mdp").style.backgroundColor = "#ff5b58";
            return mdpOk = false;

        } else if (document.getElementById("mdp").value.length < 4) {
            document.getElementById("messageMdp").hidden = false;
            document.getElementById("mdp").style.backgroundColor = "#ff5b58";
            return mdpOk = false;
        }

    }


    function verifMdp() {
        let mdp = document.getElementById("mdp").value;
        let mdpv = document.getElementById("mdpv").value;
        if (mdpv === mdp) {
            document.getElementById("mdpv").style.backgroundColor = "#b4ffaf";
            return mdpvOk = true;
        } else {
            document.getElementById("mdpv").style.backgroundColor = "#ff5b58";
            alert("La vérification ne correspond pas au mot de passe saisie");
            return mdpvOk = false;
        }
    }

   function activateSubmit() {
        if (preOk === false || mailOk === false || mdpOk === false || mdpvOk === false) {
            document.querySelector('[type="submit"]').disabled = true;
        }else{
            document.querySelector('[type="submit"]').disabled = false;
        }
    }

    window.onload = function () {
        document.getElementById("messagePseudo").hidden = true;
        document.getElementById("messageMdp").hidden = true;
    };

