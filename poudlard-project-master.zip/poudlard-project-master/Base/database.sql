-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  lun. 03 déc. 2018 à 10:16
-- Version du serveur :  10.1.36-MariaDB
-- Version de PHP :  7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `poudlard-project`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

CREATE TABLE `administrateur` (
  `id_admin` int(10) UNSIGNED NOT NULL,
  `email_admin` varchar(150) NOT NULL,
  `mdp_admin` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `communaute`
--

CREATE TABLE `communaute` (
  `id_com` int(10) UNSIGNED NOT NULL,
  `prenom_com` varchar(50) NOT NULL,
  `nom_com` varchar(50) NOT NULL,
  `pseudo_com` varchar(50) NOT NULL,
  `identifiant_com` varchar(50) NOT NULL,
  `mdp_com` varchar(400) NOT NULL,
  `role_com` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `communaute`
--

INSERT INTO `communaute` (`id_com`, `prenom_com`, `nom_com`, `pseudo_com`, `identifiant_com`, `mdp_com`, `role_com`) VALUES
(1, 'jkl', 'jkl', 'jkl', 'iop@klm.fr', 'klm', 'Administrateur'),
(2, 'ana', 'feuvrr', 'feuv', 'anaise.feuvrier@hei.yncrea.fr', '$argon2i$v=19$m=65536,t=5,p=1$WpyEIffbEGbIdWlGqqeCtzEDRwCIEcBVdvK+E2oGtZVdEqrI7S1d03zsAnsJW0zCYN7jwFaK2sxn+lOZt3KBtjpTv4v3xueBOx55ndFAj7PWBLN+fFZy4kXlRr/DJfIOHo1nG7qmqXN4q2J1LM23YJfUbwcpLCRHbv02wYcFO4Y$pIS4j/nV2MdubS3Uc8YbcF/s3jE1ZFjlWXBg2/Nl2PtombdP1NcuX5Bq0GaODOYsY8a15si8zLwVt79Eve/gxAFwodlemgIhwgvAiP+RBYAo9C9pQAIZaKUnCBNomNpp9Gq9qw28Qnuo7blhWXKAuQ21z1NUT3+2khiMee0d3bU', 'Utilisateur');

-- --------------------------------------------------------

--
-- Structure de la table `dailyprophet`
--

CREATE TABLE `dailyprophet` (
  `id_news` int(10) UNSIGNED NOT NULL COMMENT 'id des articles',
  `titre_news` varchar(150) NOT NULL,
  `article_news` text NOT NULL,
  `rubrique_news` varchar(150) NOT NULL,
  `auteur_news` varchar(150) NOT NULL,
  `datepub_news` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `dailyprophet`
--

INSERT INTO `dailyprophet` (`id_news`, `titre_news`, `article_news`, `rubrique_news`, `auteur_news`, `datepub_news`) VALUES
(1, 'Promotions', 'Chez Fleury & Bott retrouvez vos livres préférés avec des réductions plus qu\'avantageuses ! Les Hauts de Hurlements d\'Emily Brown, Mémoire d’Outre-La-Tombe de Brigthcastle ou encore Pourquoi Avada Kedavra n\'est pas toujours la solution ! de Tom Jurassik à -50% !', 'Annonce', 'Diane Foy', '26/11/2018'),
(2, 'Meutres de moldus à la gare de Goathland, North York', 'Le comté de North York connait une nouvelle fois l\'effroi alors que plusieurs moldus ont été retrouvés assassinés dans une maison de campagne dans des circonstances particulières. La police moldue continue ses investigations et le Département de la Justice Magique se tient prêt et pourrait être amené à intervenir si la situation l\'impose.', 'Fait Divers', 'Elizabeth Leaumof', '03/12/2018'),
(3, 'Mordicus Balkanus !', 'Encore une fois les Balkanus sont inquiétés par la justice moldue et magique. Ils sont cette fois accusés de détournements de fonds à l’aide du sort Levallois Perix. Le Fisc Magique s’occupe en ce moment même de l’affaire. Le couple pourrait se retrouver une nouvelle fois dans une mauvaise passe. Affaire à suivre …', 'Fait Divers', 'Camilia Peasant', '12/02/2019'),
(4, 'Hungry kid aka Shrimpy frappe encore !', 'La délinquance frappe une nouvelle fois la ville de Londres sous le nom de Shrimpy. Ce délinquant connu des Services Sociaux Magiques a sous le coup de la faim une nouvelle fois braqué une épicerie. Bakery&Co s\'est donc retrouvée confronté à l\'énergumène qui a utilisé la magie afin de soustraire au commerçant des ButterBeers et des Pains au Chocolat. Le boulanger s\'est retrouvé victime du sort Crache-Limace lorsqu\'il a repris son agresseur qu\'il lui avait dit alors « Des chocolatines ou la vie ». Suite à ce braquage, le Département des Accidents et Catastrophes Magiques a été saisi. Il risque une peine d\'au moins 6 ans pour braquage à baguette armée et injure envers les pains au chocolat.', 'Fait Divers', 'Mathilda February', '06/11/2018'),
(5, 'Amour ou haine ? ', 'Encore une fois les amoureux Bellatrix et Brian (ou Bellian pour les fans) sont dans la tourmente. En effet, il y a de l\'orage dans l\'air entre les deux (feu ?) tourtereaux. Bellatrix serait en effet volage : elle aurait été aperçue au détour d’une ruelle vers le Chemin de Travers accompagnée par un homme encapuchonné et apparemment sans nez. Nous reviendrons vers vous le plus tôt possible pour de nouvelles informations.', 'Potins', 'Rita Skeeter', '03/12/2018'),
(6, 'Annonce professeur particulier', 'Cherche élève sérieux et qui s\'investisse dans ses études. Soutient possible dans les matières suivantes : Défense contre les forces du Mal, Occlumancie et Potions\r\nFamille Potter s\'abstenir (à part Lily)\r\n', 'Annonce', 'Severus Rogue', '02/11/2018'),
(7, 'Edito : Sorcellerie et Numérique', 'A l’heure où le numérique prend de plus en plus de place, il paraît essentiel de se poser la question que se passera-t-il demain ? Car nous ne nous pouvons pas nous permettre de nous laisser par la musique doucereuse de la technologie. Il est nécessaire de la comprendre afin de mieux en appréhender les bénéfices et les inconvénients. Notre société est aujourd\'hui très connectée, peut-être même trop. Les magasins emblématiques de la magie comme la librairie Fleury & Bott qui aujourd\'hui n\'attire plus les étudiants sorciers qui disposent de leur tablette et téléchargent leurs livres scolaires dessus. Cette vitrine emblématique du Chemin de Traverse sera-t-elle remplacée elle aussi par Mac Donax ? Les chaudrons nécessaires au cours de potions commencent eux aussi à être délaissés pour laisser la place aux cuves portatives en silicones. Certes elles sont plus pratiques à porter par leur légèreté mais par leur faute, l’industrie de la fonte se porte au plus mal et de nombreuses usines se voient menacées de fermeture. Ceux ne sont que deux exemples parmi tant d\'autres, qui illustrent les dangers qui menacent aujourd\'hui le monde tel que nous le connaissons.\r\nMême si le Ministre de la Magie se veut rassurant pour l\'avenir, il semble orienté son PPRRROOOOOOOJJJEEETTT vers les entreprises du numériques et non vers l\'industrie en péril qui représente aujourd’hui 20% des emplois du pays.\r\n', 'Edito', 'Hannah Invineyard', '09/12/2018'),
(8, 'Billet sur la sacralité ', '« Je suis sacré, je suis un mage du Magenmagot ». Ces paroles prononcées par Mélanchonus resteront gravées longtemps. Alors que le Département des Mystères enquêtait sur le mystère que représente la Magie Insoumise, son chef a fustigé les représentants du Département les traitant comme des sous-fifres. Ce Mage issu du peuple se promet de représenter les petites gens avec tout le respect qui leur ai dû, preuve à l\'appui. Robespierrus lui aussi souhaitait le bien de son peuple, la Terreur n\'étant qu\'une regrettable erreur', 'Fait Divers', 'Guillaume Meuricix ', '21/10/2018'),
(9, 'Nouvelle législation sur les voitures magiques\r\n', 'Un nouveau décret émanant du Ministère de la Magie a été instauré aujourd\'hui qui consiste à différencier les voitures selon leur âge. Les vieilles voitures étant très gourmandes en sort comparées aux derniers modèles, les autorités ont cherché à réduire leur nombre afin d’éviter aux sorciers de trop se fatiguer lors de leur utilisation. Le but de ce décret est clair : améliorer la qualité de vie des citoyens disposants d\'anciens véhicules en leur interdisant de circuler tous les week-ends. Son application devrait se faire graduellement au cours des prochains mois à venir. Le porte-parole du Ministère devrait éclaircir ce sujet lors de la prochaine conférence de presse.', 'Fait Divers', 'Agatha Cashewnut', '15/12/2018'),
(10, 'Recette Gourmande du chef Hervé-Ravelis', 'Le risotto à la Citrouille \r\nPour 4 personnes,\r\n500g de citrouille\r\n320g de riz rond\r\n1 oignon\r\n30g de beurre\r\n1l de beurre\r\n1l de bouillon\r\n80g de parmesan\r\nSel et poivre\r\nExtrait de musaraigne\r\n\r\n1.	Découper la citrouille en cube. Emincer l\'oignon et le faire brûler dans du beurre. Rajouter les morceaux coupés de citrouille et l’extrait, les faire revenir 10 à 15 minutes jusqu\'à ce que les morceaux se démêlent. Rajouter un peu d’eau si jugé nécessaire\r\n2.	Ajouter le riz et mélanger. Mouiller le mélange riz/citrouille avec le bouillon et continuer surtout de mélanger. Rajouter le bouillon. Compter 2 heures de cuisson.\r\n3.	Lorsque le riz est dissous, éteindre le feu et ajouter le parmesan. Bien mélanger et ajouter le beurre restant. Server aussitôt car le risotto ne se réchauffe pas. A bientôt pour une nouvelle recette !\r\n\r\n', 'Cuisine', 'Martin Hervé-Ravelis', '13/11/2018'),
(11, 'Soirée Raclette ', 'La Gazette du Sorcier vous invite à sa raclette magique ! Venez vous régaler à nos frais au siège du journal pour cela inscrivez-vous à la loterie Raclette en ligne et vous ferez peut être partie des 10 élus. Fromagus Racletus comme on dit ! PS : nous fournissons les poêlons volants, pas besoin de ramener les vôtres. ', 'Annonce', 'Alexia  Darius', '19/12/2018');

-- --------------------------------------------------------

--
-- Structure de la table `fleurybott`
--

CREATE TABLE `fleurybott` (
  `id_livre` int(11) UNSIGNED NOT NULL,
  `titre_livre` varchar(100) NOT NULL,
  `type_livre` varchar(100) NOT NULL,
  `image_livre` varchar(100) NOT NULL,
  `prix_livre` double(10,2) NOT NULL,
  `auteur_livre` varchar(100) NOT NULL,
  `description_livre` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `fleurybott`
--

INSERT INTO `fleurybott` (`id_livre`, `titre_livre`, `type_livre`, `image_livre`, `prix_livre`, `auteur_livre`, `description_livre`) VALUES
(1, 'Livre invisible de l\'invisibilité', 'Scolaire', 'support.jpg', 10.00, 'Gilderoy Lockhart', 'Nouveau livre sortie cette année pour les apprentis sorciers qui rentrent en première année. Dedans tous les sorts basiques sont présents. La seule chose à savoir faire le trouver car ,oui, il est invisible. Alors amusez-vous bien !'),
(2, 'Monstrueux livre des monstres', 'Roman', 'livreMonstre.jpg', 3.00, 'Gilderoy Lockhart', 'Ce livre va permettre à vos enfants d’affronter la vie par la peur. Lisez tous les soirs une histoire et votre enfant sera encore plus terrorisé que la veille ! De quoi assurer l\'ambiance à la maison'),
(3, 'Chasse aux Loups Garous', 'Roman', 'chasseLoupGarou.png', 0.50, 'Rita Skeeter', 'Ce livre permettra de se faire des amis facilement. Ce livre est comparable à un jeu de rôle. De bonnes soirées en perspective en agréable compagnie!'),
(4, 'Livre de français - classe 6ème (moldu)', 'Scolaire ', 'francais.jpg', 0.30, 'Hachette', 'Livre pour niveau 6ème. Les moldus pourront connaitre la grammaire et la conjugaison jusqu\'au bout des doigts.'),
(5, 'Le livre des incantations', 'Scolaire', 'livreIncantation.jpg', 0.10, 'Eric Pier Sperandio', 'Livre de sorts pour magicien confirmé. Ce livre n’étant pas pour tout le monde, assez élevé est demandé avant l’achat via un certificat de niveau. Faites attention ce livre vous permettra d\'avoir vos buses haut la main !'),
(6, 'Collection cabane magique (moldu)', 'Roman', 'cabaneMagique.png ', 0.10, 'Mary POPE OSBORNE', 'Livre pour enfant. Chaque tome raconte une histoire avec comme personnages principales 2 enfants. Les personnages principaux, Tom et Léa, poursuivent des aventures toujours plus improbables au cœur d\'un univers magique. Allez les moldus !!'),
(7, 'Vie et mensonges d’Albus Dumbledore', 'Biographie', 'vieMensonge.jpg', 1.00, 'Rita Skeeter', 'Ce livre rétablit la vérité sur la vie de Dumbledore. . Ne cherchez pas à réfuter ce qui est écrit, seule la pure vérité est inscrite, foi de Rita Skeeter !'),
(8, 'Griffes de lézard d’Afrique', 'Roman de voyage', 'griffeLezard.png', 0.20, 'Rita Skeeter', 'Ce livre vous permettra de voyager au cœur de l\'Afrique sans dépenser un sou. Vous y découvrirez l\'univers magique de l\'Afrique encore trop méconnu aujourd\'hui . '),
(9, 'Le guide officiel de la Coupe du Monde de Quidditch', 'Livre d’éducation sportive', 'guideQuidditch.jpg', 5.00, 'Commission de Quidditch de la Conférence internationale des sorciers', 'Grâce à ce livre aucune règle ne vous échappera. Le prix est conséquent mais aucune défaite ne suivra cette lecture. Ce livre est la clé de réussite du Quidditch. Serez-vous le prochain Viktor Krum ?'),
(10, 'Livre des potions', 'Scolaire', 'livrePotion.jpg', 0.50, 'Zygmunt Budge', 'Ce livre énonce toutes les principales potions à connaitre. Il aborde dans un premier temps les potions basiques tout comme les potions plus complexes jusqu\'au plus dangereuses ! Serez-vous à la hauteur de ce livre ? '),
(11, 'Ma vie de cracmol', 'Roman', 'vieCracmol.jpg', 0.20, 'Angus Buchanan', 'Ce livre illustre le combat pour la reconnaissance du statut de cracmol du personnage principal, sa difficulté à accepter les autres et s\'accepter soi-même. Un récit poignant qui remettra en perspective votre vision des cracmols'),
(12, 'Métamor Phoseon', 'Roman imaginaire', 'metamor.jpg', 0.20, 'Gilderoy Lockart', 'Livre qui raconte les mythes et les légendes de la magie. Livre parfait si vous avez besoin de développer votre imaginaire ou de vous déconnecter.'),
(13, 'Vie et habitat des animaux fantastiques', 'Scolaire', 'vieHabitat.jpg', 0.50, 'Norbert Dragonneau', 'Ce manuel est conseillé pour tout ceux qui étudient à Poudlard . Ce livre permet un beau taux de réussite des élèves aux examens de soins aux créatures. Ecrit par un grand expert qui a lui aussi étudié à Poudlard. '),
(14, 'Présage de mort : que faire lorsque l’on sent venir le pire', 'Inconnu ou non défini', 'persageMort.png', 2.30, 'Rita Skeeter', 'Ce livre parait un peu cher, mais il vous sauvera surement la vie, alors qu\'est ce que 2.30 Gallions comparer à une vie ? Lisez ce livre attentivement et vous pourrez peut-être anticiper le pire.'),
(15, 'Sorts contre-sorts', 'Scolaire', 'sortCSort.png', 0.40, 'Vindictus Viridan', 'Ce livre est constitué de maléfices (bloque-jambes, boutons, pot de colle, saucisson…) et de sortilèges (des boutons, de chatouilles, de crâne chauve, de jambe en coton, de langue de plomb…). Que de bonnes blagues en perspective !');

-- --------------------------------------------------------

--
-- Structure de la table `madameguipuire`
--

CREATE TABLE `madameguipuire` (
  `id_gu` int(11) NOT NULL,
  `titre_gu` varchar(50) NOT NULL,
  `image_gu` varchar(50) NOT NULL,
  `description_gu` text NOT NULL,
  `prix_gu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `madameguipuire`
--

INSERT INTO `madameguipuire` (`id_gu`, `titre_gu`, `image_gu`, `description_gu`, `prix_gu`) VALUES
(1, 'Robe Gryffondor', 'robegryffindor.png', 'Robe pour les élèves de la maison Gryffondor', 5),
(2, 'Robe Poufsouffle', 'robehufflepuff.png', 'Robe pour les élèves de la maison Poufsouffle', 5),
(3, 'Robe Serdaigle', 'roberavenclaw.png', 'Robe pour les élèves de la maison Serdaigle', 5),
(4, 'Robe Serpentard', 'robeslytherin.png', 'Robe pour les élèves de la maison Serpentard', 5),
(5, 'Chaussettes Gryffondor', 'socksgryffindor.png', 'Chaussettes pour les élèves de la maison Gryffondor', 1),
(6, 'Chaussettes Poufsouffle', 'sockshufflepuff.png', 'Chaussettes pour les élèves de la maison Poufsouffle', 1),
(7, 'Chaussettes Serdaigle', 'socksravenclaw.png', 'Chaussettes pour les élèves de la maison Serdaigle', 1),
(8, 'Chaussettes Serpentard', 'socksslytherin.png', 'Chaussettes pour les élèves de la maison Serpentard', 1),
(9, 'Tee-Shirt Gryffondor', 'teeshirtgryffindor.png', 'Tee-shirt pour les élèves de la maison Gryffondor', 4),
(10, 'Tee-Shirt Poufsouffle', 'teeshirthufflepuff.png', 'Tee-shirt pour les élèves de la maison Poufsouffle', 4),
(11, 'Tee-Shirt Serdaigle', 'teeshirtravenclaw.png', 'Tee-shirt pour les élèves de la maison Serdaigle', 4),
(12, 'Tee-Shirt Serpentard', 'teeshirtslytherin.png', 'Tee-shirt pour les élèves de la maison Serpentard', 4),
(13, 'Tee-Shirt Poudlard', 'teeshirthogwarts.png', 'Tee-shirt pour tous les élèves de Poudlard', 4),
(14, 'Cravate Gryffondor', 'tiegryffindor.png', 'Cravate pour les élèves de la maison Gryffondor', 2),
(15, 'Cravate Poufsouffle', 'tiehufflepuff.png', 'Cravate pour les élèves de la maison Poufsouffle', 2),
(16, 'Cravate Serdaigle', 'tieravenclaw.png', 'Cravate pour les élèves de la maison Serdaigle', 2),
(17, 'Cravate Serpentard', 'tieslytherin.png', 'Cravate pour les élèves de la maison Serpentard', 2),
(18, 'Ensemble hiver Gryffondor', 'wintergryffindor.png', 'Ensemble d\'hiver pour les élèves de la maison Gryffondor', 3),
(19, 'Ensemble hiver Poufsouffle', 'winterhufflepuff.png', 'Ensemble d\'hiver pour les élèves de la maison Poufsouffle', 3),
(20, 'Ensemble hiver Serdaigle', 'winterravenclaw.png', 'Ensemble d\'hiver pour les élèves de la maison Serdaigle', 3),
(21, 'Ensemble hiver Serpentard', 'winterslytherin.png', 'Ensmeble d\'hiver pour les élèves de la maison Serpentard', 3);

-- --------------------------------------------------------

--
-- Structure de la table `ollivander`
--

CREATE TABLE `ollivander` (
  `id_ol` int(10) UNSIGNED NOT NULL,
  `titre_ol` varchar(50) NOT NULL,
  `image_ol` varchar(50) NOT NULL,
  `prix_ol` double(10,2) NOT NULL,
  `description_ol` text NOT NULL,
  `type_ol` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `ollivander`
--

INSERT INTO `ollivander` (`id_ol`, `titre_ol`, `image_ol`, `prix_ol`, `description_ol`, `type_ol`) VALUES
(1, 'Baguette - Ron Weasley', 'baguetteRonWeasley.png', 15.00, 'Deuxième baguette de Ron, la première étant cassée. ', 'Bois de saule / crin de licorne / 35 cm'),
(2, 'Baguette - Drago Malefoy', 'baguetteDracoMalefoy.png', 10.00, 'Baguette utilisée par Drago pendant toute sa scolarité, et a été en sa possession jusqu\'à la bataille du manoir Malefoy où Harry, en le désarmant, en est devenu le maître.', 'Bois d\'aubépine / crin de licorne / 25 cm / relativement souple'),
(3, 'Baguette - Bellatrix Lestrange', 'baguetteBellatrixLestrange.png', 7.00, 'La baguette de Bellatrix a été utilisée lors de la bataille du Département des mystères.', 'Bois de noyer / ventricule de dragon / 31,8 cm / souple'),
(4, 'Baguette - Severus Rogue', 'baguetteSeverusRogue.png', 8.00, 'Utilisée par Rogue pendant toute sa scolarité et en tant que professeur à Poudlard.', 'Bois de vigne / ventricule de dragon'),
(5, 'Baguette - Alastor Maugrey Fol Oeil', 'baguetteAlastor.png', 3.00, 'Retrouvé lors de la bataille à Poudlard, nous n\'avons pu retrouver son propriétaire. Cependant, il est certain qu\'elle ait participé au combat décisif opposant les Mangemorts et l\'Ordre, mais dans quel camp ? Mystère ...', 'inconnu'),
(6, 'Baguette - Lord Voldemort', 'baguetteLordVoldemort.png', 20.00, 'Jumelle de la baguette d\'Harry Potter, elles ne peuvent s’entre tuer. Cela poussera Voldemort à utiliser d\'autres baguettes contre Harry.', 'Bois d\'if / plume de phénix / 33,75 cm'),
(7, 'Baguette - Harry Potter', 'baguetteHarryPotter.png', 19.00, 'Fabriquée à partir d\'une plume de Fumseck, elle est liée à une autre baguette, celle de Voldemort, elle aussi munie d\'une plume du même phénix. ', 'Bois de houx / plume de phénix / 27,5 cm / très souple'),
(8, 'Baguette - Narcissa Malefoy', 'baguetteNarcissaMalefoy.png', 9.00, 'Utilisée par Malefoy contre l\'Ordre du Phénix puis par Voldemort pour tuer Harry (en vain, bien sûr).', 'Bois d\'orme / ventricule de dragon'),
(9, 'Baguette - Hermione Granger', 'baguetteHermioneGranger.png', 10.00, 'La baguette a été abandonné au manoir des Malefoy pendant la fuite de nos héros, nos équipes ont ainsi pu la récupérer.', 'Bois de vigne / ventricule de dragon / 27,30 cm'),
(10, 'Baguette - Miverna McGonagall', 'baguetteMcGonagall.png', 5.00, 'Utilisée par le professeur à Poudlard.', 'Bois de sapin / ventricule de dragon / 23,75 cm / rigide'),
(11, 'Baguette - Cedric Diggory', 'baguetteCedricDiggory.png', 5.00, 'Utilisée par Diggory pendant le tournoi des trois Sorciers', 'Bois de frêne / crin de licorne / 30,5 cm / souple'),
(12, 'Baguette - Albus Dumbledore', 'baguetteDumbledore.png', 20.00, 'L\'une des baguettes les plus puissantes du monde magique', 'Bois de sureau / crin de queue de Sombral / 38 cm / rigide'),
(13, 'Baguette - Fleur Delacour', 'baguetteFleurDelacour.png', 5.00, 'Utilisée par Delacour pendant le tournoi des trois Sorciers', 'Bois de rose / cheveu de vélane / 23,75 cm / très rigide'),
(14, 'Baguette - Gellert Grindelwald', 'baguetteGellertGrindelwald.png', 15.00, 'Utilisée pendant la célèbre bataille le confrontant à Albus Dumbledore', 'Bois de pommier / corail'),
(15, 'Baguette - Leta Lestrange', 'baguetteLetaLestrange.png', 5.00, 'Sorcière appartenant à la très célèbre famille Lestrange', 'Bois de vigne / plume d\'oiseau-tonnerre'),
(16, 'Baguette - Luna Lovegood', 'baguetteLunaLovegood.png', 5.00, 'Utilisée par Lovegood pendant la bataille de Poudlard', 'Bois de sycomore / poil de womatou '),
(17, 'Baguette - Mangemort', 'baguetteMangemort.png', 3.00, 'Mangemort non identifiée, utilisée pendant la bataille de Poudlard', 'Bois de tilleul / crin de Kelpy'),
(18, 'Baguette - Neville Londubat', 'baguetteNevilleLongdubat.png', 10.00, 'Utilisée pendant la bataille du Département des Mystères et celle de Poudlard', 'Bois de cerisier / crin de licorne / 33,02 cm'),
(19, 'Baguette - Norbert Dragonneau', 'baguetteNewt.png', 10.00, 'Utilisée par le célèbre Norbert Dragonneau, spécialiste des créatures magiques', 'Bois de poirier / corne de Jackalope / 23,75 cm / rigide'),
(20, 'Baguette - Nicolas Flamel', 'baguetteNicolasFlamel.png', 5.00, 'Utilisée par le célèbre alchimiste pour créer la Pierre Philosophale', 'Bois d\'Erable / ventricule de dragon'),
(21, 'Baguette - Percival Graves', 'baguettePercivalGraves.png', 3.00, 'Ancien auror du déparatement de la justice magique', 'Bois d\'ébène / corne de basilic '),
(22, 'Baguette - Porpentina Goldstein', 'baguettePorpentinaGoldstein.png', 5.00, 'Ancienne auror du département de la justice magique', 'Bois de sapin / plume de phénix / 23,75 cm / rigide'),
(23, 'Baguette - Queenie Goldstein', 'baguetteQueenieGoldstein.png', 5.00, 'Legilimens puissante, sorcière américaine', 'Bois de rose / moustache de troll / 23,75 cm / rigide'),
(24, 'Baguette - Seraphina Picquery', 'baguetteSeraphinaPicquery.png', 3.00, 'Ancienne présidente du congrès magique américain', 'Bois d\'aubépine des marais / Poil de rougarou'),
(25, 'Baguette - Sirius Black', 'baguetteSiriusBlack.png', 15.00, 'Utilisée par Sirius Black juste avant sa mort pendant la bataille du département des mystères', 'Bois de frêne / ventricule de dragon / 23,75 cm / rigide'),
(26, 'Baguette - Theseus Dragonneau', 'baguetteTheseusScamander.png', 5.00, 'Frère de Norbert Dragonneau, ancien auror du département de la justice magique', 'Bois d\'ébène / plume d\'oiseau-tonnerre / 23,75 cm / rigide'),
(27, 'Baguette - Nymphodora Tonks', 'baguetteTonks.png', 10.00, 'Ancienne auror et membre de l\'ordre du Phénix', 'Bois de sapin / crin de licorne / 23,75 cm / rigide'),
(28, 'Baguette - Xenophilius Lovegood', 'baguetteXenophiliusLovegood.png', 5.00, 'Père de Luna Lovegood, journaliste', 'Bois de vigne / ventricule de dragon / 23,75 cm / rigide'),
(29, 'Baguette - Ginny Weasley', 'baguetteGinnyWeasley.png', 12.00, 'Utilisée pendant la bataille de Poudlard et du département des mystères', 'Bois d\'if / ventricule de dragon');

-- --------------------------------------------------------

--
-- Structure de la table `quidditch`
--

CREATE TABLE `quidditch` (
  `id_qd` int(11) NOT NULL,
  `titre_qd` varchar(50) NOT NULL,
  `image_qd` varchar(50) NOT NULL,
  `description_qd` text NOT NULL,
  `prix_qd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `quidditch`
--

INSERT INTO `quidditch` (`id_qd`, `titre_qd`, `image_qd`, `description_qd`, `prix_qd`) VALUES
(1, 'Maillot Quidditch Gryffondor', 'sweatGryffondor.png', 'Maillot des joueurs de l\'équipe de Quidditch de Gryffondor', 4),
(2, 'Maillot Quidditch Poufsouffle', 'sweatHufflepuff.png', 'Maillot des joueurs de l\'équipe de Quidditch de Poufsouffle', 4),
(3, 'Maillot Quidditch Serdaigle', 'sweatSerdaigle.png', 'Maillot des joueurs de l\'équipe de Quidditch de Serdaigle', 4),
(4, 'Maillot Quidditch Serpentard', 'sweatSlytherin.png', 'Maillot des joueurs de l\'quipe de Quidditch de Serpentard', 4),
(5, 'Nimbus 2000', 'nimbus2000.jpg', 'Balai utilisé par Harry Potter pendant ses 2 premières années à Poudlard', 100),
(6, 'Nimbus 2001', 'nimbus2001.jpg', 'Balai utilisé par l\'équipe de quidditch de Serpentard', 150),
(7, 'Lunettes de protection', 'visionGoggles.jpg', 'Lunettes de protection en cas de mauvais temps ou de vent trop violent', 6),
(8, 'Vif d\'or', 'goldensnitch.jpg', 'Balle la plus importante du quidditch, peut faire gagner le match', 50),
(9, 'Equipement de quidditch', 'equipment.jpg', 'Tout l\'equipement indispensable pour pouvoir jouer au quidditch en toute sécurité', 15);

-- --------------------------------------------------------

--
-- Structure de la table `theleakychauldron`
--

CREATE TABLE `theleakychauldron` (
  `id_ch` int(11) NOT NULL,
  `titre_ch` int(11) NOT NULL,
  `image_ch` int(11) NOT NULL,
  `description_ch` int(11) NOT NULL,
  `prix_ch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `voliere`
--

CREATE TABLE `voliere` (
  `id_vol` int(10) UNSIGNED NOT NULL,
  `com_vol` text NOT NULL,
  `pseudo_vol` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `administrateur`
--
ALTER TABLE `administrateur`
  ADD PRIMARY KEY (`id_admin`);

--
-- Index pour la table `communaute`
--
ALTER TABLE `communaute`
  ADD PRIMARY KEY (`id_com`),
  ADD UNIQUE KEY `identifiant_com` (`identifiant_com`),
  ADD UNIQUE KEY `pseudo_com` (`pseudo_com`);

--
-- Index pour la table `dailyprophet`
--
ALTER TABLE `dailyprophet`
  ADD PRIMARY KEY (`id_news`);

--
-- Index pour la table `fleurybott`
--
ALTER TABLE `fleurybott`
  ADD PRIMARY KEY (`id_livre`);

--
-- Index pour la table `ollivander`
--
ALTER TABLE `ollivander`
  ADD PRIMARY KEY (`id_ol`);

--
-- Index pour la table `theleakychauldron`
--
ALTER TABLE `theleakychauldron`
  ADD PRIMARY KEY (`id_ch`);

--
-- Index pour la table `voliere`
--
ALTER TABLE `voliere`
  ADD PRIMARY KEY (`id_vol`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `administrateur`
--
ALTER TABLE `administrateur`
  MODIFY `id_admin` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `communaute`
--
ALTER TABLE `communaute`
  MODIFY `id_com` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `dailyprophet`
--
ALTER TABLE `dailyprophet`
  MODIFY `id_news` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id des articles', AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `fleurybott`
--
ALTER TABLE `fleurybott`
  MODIFY `id_livre` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `ollivander`
--
ALTER TABLE `ollivander`
  MODIFY `id_ol` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT pour la table `theleakychauldron`
--
ALTER TABLE `theleakychauldron`
  MODIFY `id_ch` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `voliere`
--
ALTER TABLE `voliere`
  MODIFY `id_vol` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
